 // serial.c

#include "QR_Code.h" 
#include "stm32f10x.h"
#include "string.h"
#include "Delay.h"

// ����USART1��GPIOʱ��
#define USART1_TX_CLK    RCC_APB2Periph_GPIOA
#define USART1_RX_CLK    RCC_APB2Periph_GPIOA

/* GM65ģ����ض��� */
#define GM65_TIMEOUT_MS        100
#define GM65_CMD_START_SCAN    0x02
#define GM65_CMD_STOP_SCAN     0x03

/* ȫ�ֱ������� */
extern int qr[6];
int qr1, qr2, qr3, qr4, qr5, qr6;
u8 Column_RxFlag = 0;

uint8_t FlagDataReady = 0;

// ��ʼ����ά����������
const QRCodeConfig qrConfigs[] = {
    {"123+123", {1, 2, 3, 1, 2, 3}, "SET_NUM(0,123,3);SET_NUM(1,123,3);\r\n"},
	{"123+132", {1, 2, 3, 1, 3, 2}, "SET_NUM(0,123,3);SET_NUM(1,132,3);\r\n"},
	{"123+213", {1, 2, 3, 2, 1, 3}, "SET_NUM(0,123,3);SET_NUM(1,213,3);\r\n"},
	{"123+231", {1, 2, 3, 2, 3, 1}, "SET_NUM(0,123,3);SET_NUM(1,231,3);\r\n"},
	{"123+312", {1, 2, 3, 3, 1, 2}, "SET_NUM(0,123,3);SET_NUM(1,312,3);\r\n"},
	{"123+321", {1, 2, 3, 3, 2, 1}, "SET_NUM(0,123,3);SET_NUM(1,321,3);\r\n"},
	{"132+123", {1, 3, 2, 1, 2, 3}, "SET_NUM(0,132,3);SET_NUM(1,123,3);\r\n"},
	{"132+132", {1, 3, 2, 1, 3, 2}, "SET_NUM(0,132,3);SET_NUM(1,132,3);\r\n"},
	{"132+213", {1, 3, 2, 2, 1, 3}, "SET_NUM(0,132,3);SET_NUM(1,213,3);\r\n"},
	{"132+231", {1, 3, 2, 2, 3, 1}, "SET_NUM(0,132,3);SET_NUM(1,231,3);\r\n"},
	{"132+312", {1, 3, 2, 3, 1, 2}, "SET_NUM(0,132,3);SET_NUM(1,312,3);\r\n"},
	{"132+321", {1, 3, 2, 3, 2, 1}, "SET_NUM(0,132,3);SET_NUM(1,321,3);\r\n"},
	{"213+123", {2, 1, 3, 1, 2, 3}, "SET_NUM(0,213,3);SET_NUM(1,123,3);\r\n"},
	{"213+132", {2, 1, 3, 1, 3, 2}, "SET_NUM(0,213,3);SET_NUM(1,132,3);\r\n"},
	{"213+213", {2, 1, 3, 2, 1, 3}, "SET_NUM(0,213,3);SET_NUM(1,213,3);\r\n"},
	{"213+231", {2, 1, 3, 2, 3, 1}, "SET_NUM(0,213,3);SET_NUM(1,231,3);\r\n"},
	{"213+312", {2, 1, 3, 3, 1, 2}, "SET_NUM(0,213,3);SET_NUM(1,312,3);\r\n"},
	{"213+321", {2, 1, 3, 3, 2, 1}, "SET_NUM(0,213,3);SET_NUM(1,321,3);\r\n"},
	{"231+123", {2, 3, 1, 1, 2, 3}, "SET_NUM(0,231,3);SET_NUM(1,123,3);\r\n"},
	{"231+132", {2, 3, 1, 1, 3, 2}, "SET_NUM(0,231,3);SET_NUM(1,132,3);\r\n"},
	{"231+213", {2, 3, 1, 2, 1, 3}, "SET_NUM(0,231,3);SET_NUM(1,213,3);\r\n"},
	{"231+231", {2, 3, 1, 2, 3, 1}, "SET_NUM(0,231,3);SET_NUM(1,231,3);\r\n"},
	{"231+312", {2, 3, 1, 3, 1, 2}, "SET_NUM(0,231,3);SET_NUM(1,312,3);\r\n"},
	{"231+321", {2, 3, 1, 3, 2, 1}, "SET_NUM(0,231,3);SET_NUM(1,321,3);\r\n"},
	{"312+123", {3, 1, 2, 1, 2, 3}, "SET_NUM(0,312,3);SET_NUM(1,123,3);\r\n"},
	{"312+132", {3, 1, 2, 1, 3, 2}, "SET_NUM(0,312,3);SET_NUM(1,132,3);\r\n"},
	{"312+213", {3, 1, 2, 2, 1, 3}, "SET_NUM(0,312,3);SET_NUM(1,213,3);\r\n"},
	{"312+231", {3, 1, 2, 2, 3, 1}, "SET_NUM(0,312,3);SET_NUM(1,231,3);\r\n"},
	{"312+312", {3, 1, 2, 3, 1, 2}, "SET_NUM(0,312,3);SET_NUM(1,312,3);\r\n"},
	{"312+321", {3, 1, 2, 3, 2, 1}, "SET_NUM(0,312,3);SET_NUM(1,321,3);\r\n"},
	{"321+123", {3, 2, 1, 1, 2, 3}, "SET_NUM(0,321,3);SET_NUM(1,123,3);\r\n"},
	{"321+132", {3, 2, 1, 1, 3, 2}, "SET_NUM(0,321,3);SET_NUM(1,132,3);\r\n"},
	{"321+213", {3, 2, 1, 2, 1, 3}, "SET_NUM(0,321,3);SET_NUM(1,213,3);\r\n"},
	{"321+231", {3, 2, 1, 2, 3, 1}, "SET_NUM(0,321,3);SET_NUM(1,231,3);\r\n"},
	{"321+312", {3, 2, 1, 3, 1, 2}, "SET_NUM(0,321,3);SET_NUM(1,312,3);\r\n"},
	{"321+321", {3, 2, 1, 3, 2, 1}, "SET_NUM(0,321,3);SET_NUM(1,321,3);\r\n"}
};

// ����GPIO����
void USART1_GPIO_Config(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(USART1_TX_CLK|USART1_RX_CLK, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
}

// ������USART �ڳ�ʼ��
void Usart1_Config(void) {		
    USART_InitTypeDef USART_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    USART1_GPIO_Config();
    
    USART_InitStructure.USART_BaudRate = 9600; // ������
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(USART1, &USART_InitStructure);
    USART_Cmd(USART1, 	ENABLE);
    
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
    NVIC_Init(&NVIC_InitStructure);
}

// ����1�����ַ���
void uart1_SendString(u8* str) {
    while (*str) {
        USART_SendData(USART1, *str++);
        while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    }
}

// ����GM65����
void GM65_SendCommand(uint8_t* cmd, uint8_t length) {
    for (uint8_t i = 0; i < length; i++) {
        USART_SendData(USART1, cmd[i]);
        while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    }
}

// GM65��ʼ��
void GM65_Init(void) {
    Usart1_Config();
    Delay_ms(100);
    
    uint8_t cmd[5] = {0xAA, 0x55, GM65_CMD_START_SCAN, 0x01};
    GM65_SendCommand(cmd, 5);
}


void USART1_IRQHandler(void) {
    static u8 RxState = 0;
    static u8 pRxPacket = 0;
    static u8 expectedLength = 0;
    
    if (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == SET) {
        u8 RxData = USART_ReceiveData(USART1);
        
        switch (RxState) {
            case 0:
                if (RxData == 0x03) {
                    RxState = 1;
                    pRxPacket = 0;
                    expectedLength = 0;  // ����expectedLength
                    memset(QR_Code_RxPacket, 0, sizeof(QR_Code_RxPacket)); // ���㻺����
                }
                break;
            case 1:
                if (RxData == 0x00) {
                    RxState = 2;
                } else {
                    RxState = 0; // ����״̬
                }
                break;
            case 2:
                expectedLength = RxData;
                if (expectedLength > 0 && expectedLength < QR_CODE_MAX_LEN) {
                    RxState = 3;
                    pRxPacket = 0;
                } else {
                    RxState = 0; // ��Ч���ȣ�����״̬
                }
                break;
            case 3:
                if (pRxPacket < expectedLength) {
                    QR_Code_RxPacket[pRxPacket++] = RxData;
                }
                if (pRxPacket >= expectedLength) {
                    QR_Code_RxPacket[pRxPacket] = '\0'; // ȷ���ַ�����ֹ
                    RxState = 0; // ֱ�ӻص���ʼ״̬
                    Column_RxFlag = 1; // ���ñ�־
                }
                break;
            // �Ƴ�case 4��ֱ����case 3��ɺ�����״̬
        }
        
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }

    if (USART_GetITStatus(USART1, USART_IT_TC) != RESET) {
        send_complete_flag = 1;
        USART_ClearITPendingBit(USART1, USART_IT_TC);
    }
}





// ��ά�봦������
int QR_Code(void) {  
    int flag = 0;  
    if (Column_RxFlag) {
        Column_RxFlag = 0;
        
        uart1_SendString((u8*)"Received QR: ");
        uart1_SendString((u8*)QR_Code_RxPacket);
        uart1_SendString((u8*)"\r\n");
        
        for (int i = 0; i < sizeof(qrConfigs) / sizeof(qrConfigs[0]); i++) {
            if (strcmp(QR_Code_RxPacket, qrConfigs[i].qrCode) == 0) {
                // ��������
                send_complete_flag = 0;
                uart1_SendString((u8*)qrConfigs[i].sendCommand);
                // �ӳ�ʱ��������ֹ����
                uint32_t timeout = 100000;
                while(!send_complete_flag && timeout--) ;
                
                // ��������
                send_complete_flag = 0;
                sendQRContentToScreen(QR_Code_RxPacket);
                timeout = 100000;
                while(!send_complete_flag && timeout--) ;
                
                processQRCode(&qrConfigs[i]);
                break;
            }
						
        }
				flag = 1;
    }
		return flag;
}
// ������ά�����ݵĺ���
void processQRCode(const QRCodeConfig* config) {
    for (int i = 0; i < 6; i++) {
        qr[i] = config->qrValue[i];
        switch (i) {
            case 0: qr1 = config->qrValue[i]; break;
            case 1: qr2 = config->qrValue[i]; break;
            case 2: qr3 = config->qrValue[i]; break;
            case 3: qr4 = config->qrValue[i]; break;
            case 4: qr5 = config->qrValue[i]; break;
            case 5: qr6 = config->qrValue[i]; break;
        }
    }
}

// ʾ����������QR_Code_RxPacket�����ݷ��͵�������
void sendQRContentToScreen(char* content) {
    char command[64];
    sprintf(command, "SET_TXT(0,'%s');\r\n", content);
    uart1_SendString((u8*)command);
}

