#ifndef __DMA__H
#define __DMA__H

#define BUFFER_SIZE 1  
extern uint8_t rxBuffer[BUFFER_SIZE];

void DMA1_Configuration(void); 
//void USART1_DMA_Config(void);
#endif 
