#include "head.h" 
#include "misc.h" // 添加，确保NVIC_PriorityGroupConfig和优先级分组宏可用
#include <usart3.h>
#include <jy61p.h>
#include <sport.h>

/**坐标系旋转变量**/
int16_t vx,vy,i;

/**定义二维码变量**/
//int qr[6] = {2,1,3,3,1,2};  // 初始化为0
int qr[6];  // 初始化为0
volatile uint8_t send_complete_flag = 0;
uint8_t send_complete_flagqr = 0;
volatile uint8_t flage_catch = 0;

// 如果这些变量在其他地方定义，保持extern声明
extern uint8_t Column_RxFlag;
extern uint8_t FlagDataReady;
uint8_t QR_Code_RxPacket[8];

// 色块数据存储
uint8_t rc = 0, rd = 0;                   // 红色块代号及扇区
uint8_t gc = 0, gd = 0;                   // 绿色块代号及扇区
uint8_t bc = 0, bd = 0;                   // 蓝色块代号及扇区
int rc_gold,rd_gold,flag_sekuai;
int flag[6];
//extern int error_x ;
//extern int error_y  ;



/**定义函数变量**/
void zhuaqu_yuanliao(int m, int n);//色块抓取函数
void cdown_one();
void ccatch_on_one();
void zdown_one();
void cdown_two();
int flage_sekuai();
/***************************************************************************************************
*	函 数 名: main
*	入口参数: 无
*	返 回 值: 无
*	函数功能: 运行主程序
*	说    明: 无
***************************************************************************************************/


int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); // 只在这里调用一次
    //机械臂初始化
//    Servo_PWM1_Init();
//    TIM3_PWM_Init();
//    TIM4_PWM_Init();
    
	  Servo_PWM_Init() ;
	  //Delay_ms(100);
    Servo0_SpeedTimer_Init();
	
    SPI_LCD_Init();         // LCD初始化
    USART2_GPIO_Config();   //色块色环识别串口
    Delay_Init();           // 延时函数初始化
    board_init();           //USART3串口初始化
    //GM65扫码模块初始化
    USART1_GPIO_Config();   
    Usart1_Config();        
    GM65_Init(); 
    usart4_Init(9600);      // jy61p
    // 初始化标志位和缓冲区
    Column_RxFlag = 0;
    FlagDataReady = 0;
    memset(QR_Code_RxPacket, 0, sizeof(QR_Code_RxPacket));
    servo_zero();    //舵机初始位置
		Delay_ms(3000);
    while (1)
    { 
			
		Car_CK(325,2000);
		Delay_ms(1200);
		Car_Forward(-575,2500);
		Delay_ms(1700);
		int flg = QR_Code( );//二维码识别及显示
		if(flg != 1){
		 while(flg != 1){
			 flg = QR_Code();
			 Car_Forward(1,2000);
		   Delay_ms(20);
			 }
		  i++; 
		 }	
			
		LCD_DisplayNumber(60,10,  qr[0],1);
		LCD_DisplayNumber(60,35,  qr[1],1);
		LCD_DisplayNumber(60,60,  qr[2],1);
		LCD_DisplayNumber(60,85,  qr[3],1);
		LCD_DisplayNumber(60,105, qr[4],1);
		LCD_DisplayNumber(60,130, qr[5],1); 
		USART_Cmd(USART1,DISABLE); 
		Car_Forward(-700-i-1,2500);
		Delay_ms(1800);
		servo_czero(); 
 	  Delay_ms(2000); 
		flage_sekuai();
	  Delay_ms(2500);
		//zdadadada(0,0); 
		zhuaqu_yuanliao(1,3);//第一次抓取
		Delay_ms(500);
		Car_Forward(250,2500);
		Delay_ms(700);
	  Car_Xuanzhuan111();
    Delay_ms(2200);
    
		Car_Forward(-1620,3000);
		Delay_ms(2000);
		Car_Xuanzhuan(90);
    Delay_ms(1500);
		adjust_body_angle(180,150);
		Delay_ms(100);
		servo_bzero(); 
		Delay_ms(2000);//3000
		dadadada(4,-22);   //第一次调整位置
    Delay_ms(500);
    cdown_one();
    Delay_ms(500);	
    ccatch_on_one();
		Delay_ms(1000);		 
		Car_Forward(810,2000);
		Delay_ms(2000);
		Car_Xuanzhuan(-90);
		Delay_ms(1500);
	  Car_Forward(770,2500);
		Delay_ms(1700);
		Delay_ms(500);
		adjust_body_angle(90,150);
		servo_bzero();
		Delay_ms(2000);//2500
		dadadada(4,-22); 
		Delay_ms(200);
		zdown_one();
		servo_zero();
	  Delay_ms(1000);
		Car_Forward(875,2500);
		Delay_ms(1800);
		Car_Xuanzhuan(-90);
		Delay_ms(1500);
		adjust_body_angle(0, 150);
		Car_Forward(390,2500);
		Delay_ms(1200);		
		
		//第一次结束到料盘位置
		//第二圈		
		servo_czero(); 
		Delay_ms(2000);
		flage_sekuai();
		Delay_ms(1500);
		servo_bzero(); 
		Delay_ms(1000);
		zdadadada(0,0); 
		
		flage_sekuai();
		Delay_ms(2500);
		zhuaqu_yuanliao(2,3);//第二次抓取
		Delay_ms(500);
		Car_Forward(250,2500);
		Delay_ms(900);
	  Car_Xuanzhuan111();
    Delay_ms(2200);
    adjust_body_angle(90,150);
		Car_Forward(-1620,3000);
		Delay_ms(2000);
		Car_Xuanzhuan(90);
    Delay_ms(1500);
		servo_bzero(); 
		Delay_ms(2000);//3500
		dadadada(4,-22);   //第二次调整位置
    Delay_ms(500);
    cdown_one();
    Delay_ms(500);	
    ccatch_on_one();
		Delay_ms(500);		 
		Car_Forward(770,2000);
		Delay_ms(1700);
		Car_Xuanzhuan(-90);
		Delay_ms(1500);
	  Car_Forward(760,2500);
		Delay_ms(1700);
		adjust_body_angle(90,150);
		servo_bzero(); 
		Delay_ms(2000);
		dadadada(4,-22); 
		Delay_ms(500);
		cdown_two();
		Delay_ms(500);
		Car_Forward(860,2500);
		Delay_ms(1800);
		Car_Xuanzhuan(-90);
		Delay_ms(1500);
		Car_Forward(1700,3000);
		Delay_ms(2000);
		Car_CK(-250,2000);
		Delay_ms(9999000);
//	




//	//调试	
//			adjust_body_angle(0, 100);
//			servo_bzero(); 
//  	  Delay_ms(4000); 
//			zdadadada(0,0); 
//			Delay_ms(600);
//			zhuaqu_yuanliao(1,3);//第一次抓取
//  		Delay_ms(500);
//			Delay_ms(9999000);
//			
//			
//			
			
////			
//			adjust_body_angle(0, 100);
//			servo_bzero(); 
//  	  Delay_ms(4000); 
//			dadadada(4,-22); 
//			Delay_ms(600);
//			cdown_one();
//			Delay_ms(600000);
//			
			
			
//   	    Car_CK(300);
//		Delay_ms(2000);
//		Car_Forward(-600);
//		Delay_ms(3000);	
////		int flg = QR_Code( );//二维码识别及显示
////		if(flg != 1){
////		 while(flg != 1){
////			 flg = QR_Code();
////			 Car_Forward(1);
////		   Delay_ms(50);
////			 }
////		  i++; 
////		 }	
//			
//		LCD_DisplayNumber(60,10,  qr[0],1);
//		LCD_DisplayNumber(60,35,  qr[1],1);
//		LCD_DisplayNumber(60,60,  qr[2],1);
//		LCD_DisplayNumber(60,85,  qr[3],1);
//		LCD_DisplayNumber(60,105, qr[4],1);
//		LCD_DisplayNumber(60,130, qr[5],1); 
//		USART_Cmd(USART1,DISABLE); 
//		Car_Forward(-670-i);
//		Delay_ms(3000);
//       //zhuaqu_align(0,-50);
//		//Delay_ms(500);
//		zhuaqu_yuanliao(1,3);//第一次抓取
//		Delay_ms(500);
//		Car_Forward(230);
//		Delay_ms(1000);
//	  Car_Xuanzhuan111();
//    Delay_ms(3000);
//		LCD_DisplayNumber(60,10, Yaw,3);
//    adjust_body_angle(90,100);
//		Car_Forward(-1650);
//		Delay_ms(3800);
//		Car_Xuanzhuan(90);
//    Delay_ms(2000);
//		adjust_body_angle(180, 100);
//		servo_czero(); 
//		Delay_ms(3000);
//		dadadada();   //第一次调整位置
//    Delay_ms(500);
//    cdown_one();
//    Delay_ms(500);	
//    ccatch_on_one();
//		Delay_ms(1000);		 
//		Car_Forward(810);
//		Delay_ms(3500);
//		Car_Xuanzhuan(-90);
//		Delay_ms(2000);
//		adjust_body_angle(90, 100);
//	  Car_Forward(850);
//		Delay_ms(3500);
//		servo_czero(); 
//		Delay_ms(3000);
//		dadadada(); 
//		Delay_ms(200);
//		zdown_one();
//		Car_Forward(860);
//		Delay_ms(3500);
//		Car_Xuanzhuan(-90);
//		Delay_ms(2000);
//		adjust_body_angle(0, 100);
//		Car_Forward(480);
//		Delay_ms(2500);		
//		Delay_ms(9999000);









// 	QR_Code();

//  LCD_DisplayNumber(60,60,1111,4);		
//  auto_adjust_angle(0, 50);
//		Delay_ms(5000);
//		  auto_adjust_angle(180, 50);
        //adjustAngle(int target, int speed);
        
//    servo_bzero();
//	  Delay_ms(7000);
//	  ycatch_red(1);
//	  jdown_green();
//	  Delay_ms(7000);	
//	  jcatch_ongreen_jgq();
//		Delay_ms(7000);	
//		servo_czero();
//	  Delay_ms(2000);	
//	  ycatch_blue(2);
//	  jdown_red();
//	  Delay_ms(7000);
//		jcatch_onred_jgq();
//		Delay_ms(7000);	

//		servo_czero();
//	  Delay_ms(2000);
//	  jdown_blue(2);
//		Delay_ms(7000);	

//	  jcatch_onblue_jgq();
//		 Delay_ms(7000);	
//		
//		 Car_CK(300);
//		while(rxFrameFlag == false);
//		rxFrameFlag = false;
//		Delay_ms(50);
//		Car_Forward(-600);
//		while(rxFrameFlag == false); 
//		rxFrameFlag = false;
//		Delay_ms(50);		
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
//		 Car_CK(300);
////		Delay_ms(2000);
//		while(rxFrameFlag == false); rxFrameFlag = false;
//		Delay_ms(50);
//		Car_Forward(-600);
////		Delay_ms(3000);
//		while(rxFrameFlag == false); rxFrameFlag = false;
//		Delay_ms(50);
//		Car_Forward(-650);
//		while(rxFrameFlag == false); rxFrameFlag = false;
//		Delay_ms(50);
//		Car_Forward(200);
//		while(rxFrameFlag == false); rxFrameFlag = false;
//		Delay_ms(50);
//	  Car_Xuanzhuan111();
//		while(rxFrameFlag == false); rxFrameFlag = false;
//		Delay_ms(50);
//		Car_Forward(-1700);
//		while(rxFrameFlag == false); rxFrameFlag = false;
//		Delay_ms(50);
//		Car_Xuanzhuan(90);
//			while(rxFrameFlag == false); rxFrameFlag = false;
//			Delay_ms(50);
//			Car_Forward(500);		
//			while(rxFrameFlag == false); rxFrameFlag = false;
//			Delay_ms(50);
//			Car_zhuanwan(250);
//			while(rxFrameFlag == false); rxFrameFlag = false;
//			Delay_ms(50);
//			Car_Forward(850);
//			while(rxFrameFlag == false); rxFrameFlag = false;
//			Delay_ms(50);
//			Car_Forward(600);
//			while(rxFrameFlag == false); rxFrameFlag = false;
//			Delay_ms(50);
//		 Car_zhuanwan(102);

//    Delay_ms(9999000.00);
        
        
//		  LCD_DisplayNumber(60,10,8,1);
////		  QR_Code();                       //获取二维码数据并在屏幕中显示
////		  dadadada();                      //调整小车位置
//		  zhuaqu_yuanliao(1,3);//第一次抓取
//			Delay_ms(20000);
//			zhuaqu_yuanliao(2,3);//第二次抓取
        
    }
}




/**********机械臂控制部分**********/
// 功能：等待rd、gd、bd状态连续稳定N次后返回
int flage_sekuai() {
    // 记录初始状态（作为基准值）
    int init_rd = rd;  // 初始rd值
    int init_gd = gd;  // 初始gd值
    int init_bd = bd;  // 初始bd值
    
    // 循环条件：当前值与初始值完全一致（任意值不一致则退出）
    while (rd == init_rd && gd == init_gd && bd == init_bd) {
        Delay_ms(1);  // 等待1ms后再次检测
    }
    
    // 当退出循环时，说明至少有一个值与初始值不一致
    return 1;  // 返回1表示状态已变化
}

// 获取当前色块所在的扇区（0 表示未找到）
int get_sector_by_color(int color) {
    if (rc == color) return rd;
    if (gc == color) return gd;
    if (bc == color) return bd;
    return 0; // 未找到
}
 
 //* 原料区抓取函数
 //* @param m：1=抓取qr前3个色块，其他=抓取后3个
 //* @param n：抓取数量（通常为3）
 
void zhuaqu_yuanliao(int m, int n)
{
    if (n <= 0 || n > 3) return;  // 参数校验
    
    int a[3];
    for (int i = 0; i < 3; i++) {
        a[i] = (m == 1) ? qr[i] : qr[i+3];
    }

    // 首次移动到扫描位置
    servo_czero();
    Delay_ms(500);  // 等待机械臂稳定
		

    // 按顺序抓取色块
    for (int i = 0; i < n; i++) {
        int target_color = a[i];
        
        // 无限循环等待目标色块出现
        while (1) {
            int current_sector = get_sector_by_color(target_color);
            
            if (current_sector != 0) {  // 找到目标色块
                // 根据色块当前所在扇区执行对应动作
                switch (current_sector) {
                    case 4: ycatch_four(target_color,i);   break;
                    case 5: ycatch_five(target_color,i);  break;
                    case 6: ycatch_six(target_color,i); break;
                    default: break;
                }
                break;  // 抓取完成，退出循环
            }
            
            Delay_ms(80);  // 短暂延迟
        }
				if(i ==2||i-3 ==2){
					servo_zero();
        }else{
        // 抓取完成后返回扫描位置
        servo_czero();
        Delay_ms(500); 					// 等待机械臂稳定
				if (i == 0||i==1||i == 3||i==4) {  // i从0开始，i=1表示第2个色块
            Delay_ms(2500);  // 等待1500毫秒（1.5秒）
        }
			}
				
    }
}

//第一次粗加工区放下.由于放下色块需要按任务码顺序
void cdown_one()
{
	for(int i=0;i<3;i++)
 {
    switch(qr[i])
   {
    case 1:jdown_red(); break;
	  case 2:jdown_green(); break;
	  case 3:jdown_blue(); break;
		
   }	
	  
 }
}

//第一次粗加工区抓取
void ccatch_on_one()
{
	 for(int i=0;i<3;i++)
 {
    switch(qr[i])
   {
    case 1: jcatch_onred_jgq(); break;
	  case 2: jcatch_ongreen_jgq(); break;
	  case 3: jcatch_onblue_jgq(); break;
		
   }	 
 }
   servo_zero();

}

//第一次暂存区放下
void zdown_one()
{
for(int i=0;i<3;i++)
 {
    switch(qr[i])
   {
    case 1:jdown_red(); break;
	  case 2:jdown_green(); break;
	  case 3:jdown_blue(); break;
		
   }	
	  
 }
}

//第二次粗加工区放下
void cdown_two()
{
for(int i=3;i<6;i++)
 {
    switch(qr[i])
   {
      case 1:jdown_redtwo(); break;
	  case 2:jdown_greentwo(); break;
	  case 3:jdown_bluetwo(); break;
		
   }	
	  
 }
   servo_zero();
}