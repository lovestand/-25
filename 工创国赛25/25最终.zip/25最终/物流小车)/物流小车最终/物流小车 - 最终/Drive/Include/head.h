#ifndef __HEAD_H
#define __HEAD_H

#include "stm32f10x.h"
#include "delay.h"
#include "led.h"  
#include "key.h"  
#include "usart.h"
#include "lcd_spi_169.h"
#include "stdio.h"
#include "lcd_spi_169.h"
#include "string.h"//�ٷ��ж��ַ�����
#include "Delay.h"
#include <math.h>
#include "Servo.h"


#endif 