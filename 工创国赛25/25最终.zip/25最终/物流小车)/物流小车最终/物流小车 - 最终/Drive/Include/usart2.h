#ifndef __USART2_H
#define __USART2_H

#include "stm32f10x.h"   

void usart4_Init(uint32_t bound);



#endif
