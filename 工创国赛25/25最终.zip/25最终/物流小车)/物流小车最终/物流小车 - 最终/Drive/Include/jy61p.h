#ifndef __JY61P_H
#define __JY61P_H

#include "stm32f10x.h" 

void jy61p_ReceiveData(uint8_t RxData);
void adjust_body_angle(float target_angle, int max_speed);
extern float Roll,Pitch,Yaw;

#endif
