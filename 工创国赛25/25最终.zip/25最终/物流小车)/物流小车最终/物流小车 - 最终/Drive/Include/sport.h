#ifndef __SPORT_H
#define __SPORT_H


/**������̱���**/
#define WHEEL_DIAMETER 76.2
#define POSITION_THRESHOLD 5
#define PULSES_PER_REVOLUTION 3200
#define VEHICLE_LENGTH_MM 177.0f      // ���������ף�
#define VEHICLE_WIDTH_MM 188.0f       // ���������ף�
#define ROLLER_ANGLE_DEG 45.0f        // ���ӽǶȣ��ȣ�

void houtui(int spd);
void qianjin(int spd);
void zuopingyi(int spd);
void youpingyi(int spd);
void Car_Forward(int distance,int fspeed);
void Car_Translation(int Distance);
void Car_Xuanzhuan(int AG);	
void Car_CK(int dis,int fspeed);
void Car_zhuanwan(int distance);
void zdadadada(int target_Kx, int target_Ky);
void dadadada(int target_x, int target_y);
void zhuaqu_align(int target_x, int target_y);
void Car_Xuanzhuan111();
#endif