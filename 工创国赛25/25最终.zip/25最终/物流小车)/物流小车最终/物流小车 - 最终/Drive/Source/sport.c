#include "head.h" 
#include <usart3.h>
#include <sport.h>

// 首先在文件开头定义 min 和 max 宏
//#define min(a, b) ((a) < (b) ? (a) : (b))
//#define max(a, b) ((a) > (b) ? (a) : (b))
#define DEAD_ZONE 3
#define Time 5
#define Time1 5

#define xspeed 150        //旋转速度
float M_PI = 3.14;

/**色块色环变量**/
int8_t cx,cy,kx,ky; 
uint8_t colord;
int error_x;
int error_y;
int tm=50;

int calculate_pulses_mm(int distance_mm) //
	{
	double circumference_mm = M_PI * WHEEL_DIAMETER; 
	double revolutions = distance_mm / circumference_mm; 
	int pulses_needed = revolutions *3200;
	return pulses_needed;
}
	
int calculate_single_wheel_pulses(int angle_deg) {
    // 1. 计算半长和半宽（单位：mm）
    const float half_length_mm = VEHICLE_LENGTH_MM / 2.0f;
    const float half_width_mm = VEHICLE_WIDTH_MM / 2.0f;
 
    // 2. 计算旋转半径 r（单位：mm）
    const float r_mm = sqrtf(half_length_mm * half_length_mm + half_width_mm * half_width_mm);
 
    // 3. 将角度转换为弧度
    const float theta_rad = angle_deg * (float)(M_PI / 180.0f);
 
    // 4. 计算辊子角度的余弦值
    const float cos_alpha = cosf(ROLLER_ANGLE_DEG * (float)(M_PI / 180.0f));
 
    // 5. 计算脉冲数（浮点）
    const float pulse_float = (theta_rad * r_mm * PULSES_PER_REVOLUTION) / 
                             (M_PI * WHEEL_DIAMETER * cos_alpha);
 
    // 6. 四舍五入并返回整数脉冲数
    const int32_t pulse = (int32_t)roundf(pulse_float);
    
    return pulse;
}
void Car_CK(int dis,int fspeed)
{ 
  int mC;
  if(dis >= 0 ){
	mC=calculate_pulses_mm(dis);
	Emm_V5_Pos_Control(2, 1, fspeed, 30, mC,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(4, 0, fspeed, 30, mC,0, 1);
	Delay_ms(tm);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(tm);
  }
	if(dis <= 0 ){
	mC=calculate_pulses_mm(abs(dis));
	Emm_V5_Pos_Control(2, 0, fspeed, 30, mC,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(4, 1, fspeed, 30, mC,0, 1);
	Delay_ms(tm);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(tm);
  }
}
	
void Car_Forward(int distance,int fspeed)
{ 
  int mc;
  if(distance >= 0 ){
	mc=calculate_pulses_mm(distance);
	Emm_V5_Pos_Control(1, 0, fspeed, 200, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(1, 0, fspeed, 200, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(2, 0, fspeed, 200, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(2, 0, fspeed, 200, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(3, 1, fspeed, 200, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(3, 1, fspeed, 200, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(4, 1, fspeed, 200, mc,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(4, 1, fspeed, 200, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(tm);
  }
  else {
	mc=calculate_pulses_mm(abs(distance));
  Emm_V5_Pos_Control(1, 1, fspeed, 200, mc,0, 1);
		Delay_ms(10);
  Emm_V5_Pos_Control(1, 1, fspeed, 200, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(2, 1, fspeed, 200, mc,0, 1);
		Delay_ms(10);
  Emm_V5_Pos_Control(2, 1, fspeed, 200, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(3, 0, fspeed, 200, mc,0, 1);
		Delay_ms(10);
	Emm_V5_Pos_Control(3, 0, fspeed, 200, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(4, 0, fspeed, 200, mc,0, 1);
		Delay_ms(10);
	Emm_V5_Pos_Control(4, 0, fspeed, 200, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Synchronous_motion(0);
	
	Delay_ms(tm);
  }
}


void Car_Xuanzhuan(int AG)
{
  s16 jd;
  if(AG>=0){
//	jd=calculate_single_wheel_pulses(AG);
  jd=3715;
	Emm_V5_Pos_Control(1, 1, 1000, 100, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(1, 1, 1000, 100, jd,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(2, 1, 1000, 100, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(2, 1, 1000, 100, jd,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(3, 1, 1000, 100, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(3, 1, 1000, 100, jd,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(4, 1, 1000, 100, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(4, 1, 1000, 100, jd,0, 1);
	Delay_ms(tm);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(tm);
  }
  else{
//  jd=calculate_single_wheel_pulses(abs(AG));
		jd=3715;
	Emm_V5_Pos_Control(1, 0, 1000, 100, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(1, 0, 1000, 100, jd,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(2, 0, 1000, 100, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(2, 0, 1000, 100, jd,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(3, 0, 1000, 100, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(3, 0, 1000, 100, jd,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(4, 0, 1000, 100, jd,0, 1);
	Delay_ms(10);
	Emm_V5_Pos_Control(4, 0, 1000, 100, jd,0, 1);
	Delay_ms(tm);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(tm);
  }
}



void Car_Translation(int Distance)
{ 
  s16 MC;
  if(Distance>=0){
	MC=calculate_pulses_mm(Distance);
	Emm_V5_Pos_Control(1, 0, 100, 10, MC,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(2, 1, 100, 10, MC,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(3, 1, 100, 10, MC,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(4, 0, 100, 10, MC,0, 1);
	Delay_ms(tm);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(tm);
  }
  else{
	MC=calculate_pulses_mm(abs(Distance));
	Emm_V5_Pos_Control(1, 1, 100, 10, MC,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(2, 0, 100, 10, MC,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(3, 0, 100, 10, MC,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(4, 1, 100, 10, MC,0, 1);
	Delay_ms(tm);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(tm);
  
  }
}


void Car_zhuanwan(int distance)
{ 
  int mc;
  if(distance >= 0 ){
	mc=calculate_pulses_mm(distance);
	Emm_V5_Pos_Control(3, 0, 200, 70, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(4, 2, 200, 70, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(1, 1, 200*3, 70*3, mc*3,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(2, 1, 200*3, 70*3, mc*3,0, 1);
	Delay_ms(tm);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(tm);
  }
  else {
	mc=calculate_pulses_mm(abs(distance));
  Emm_V5_Pos_Control(1, 1, 200, 30, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(2, 1, 200, 30, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(3, 0, 200, 30, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(4, 0, 200, 30, mc,0, 1);
	Delay_ms(tm);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(tm);
  }
}

void Car_Xuanzhuan111()
{



	Emm_V5_Pos_Control(2, 1, 1000, 10, 4640,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(3, 1, 1000, 10, 4620,0, 1);
	Delay_ms(tm);
	Emm_V5_Pos_Control(4, 1, 730, 7, 3460,0, 1);
	Delay_ms(tm);
	Emm_V5_Synchronous_motion(0);
	Delay_ms(tm);
  
 
}

// 电机彻底停止（增加制动逻辑）
void stop_motors() {
    // 先减速到0，再强制停止（应对惯性）
    Emm_V5_Vel_Control(1, 0, 0, 0, 1);
    Emm_V5_Vel_Control(2, 0, 0, 0, 1);
    Emm_V5_Vel_Control(3, 0, 0, 0, 1);
    Emm_V5_Vel_Control(4, 0, 0, 0, 1);
    Emm_V5_Synchronous_motion(0);
    Delay_ms(20);  // 等待电机响应
    Emm_V5_Stop_Now(0, 0);  // 强制停止
    Delay_ms(20);
}


void zuopingyi(int spd)//前进
{
  Emm_V5_Vel_Control(1,1 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(2,1 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(3,0 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(4,0 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Synchronous_motion(0);Delay_ms(Time1);

}

void youpingyi(int spd)//后退
{
  Emm_V5_Vel_Control(1,0 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(2,0 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(3,1 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(4,1 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Synchronous_motion(0);Delay_ms(Time1);
}

void houtui(int spd)//左平移
{
  Emm_V5_Vel_Control(1,0 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(2,1 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(3,1 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(4,0 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Synchronous_motion(0);Delay_ms(20);
}

void qianjin(int spd)//右平移
{
  Emm_V5_Vel_Control(1,1 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(2,0 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(3,0 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Vel_Control(4,1 , spd, 0, 1); Delay_ms(Time);
	Emm_V5_Synchronous_motion(0);Delay_ms(Time1);
}


//3可以使用效果稍微好，但还是会抖动
//#define DEAD_ZONE 5               // 死区范围，减少微小调整
#define FILTER_WINDOW 5           // 滤波窗口大小，平衡平滑性和响应速度
#define MIN_SPEED 10              // 最小速度，避免动力不足
#define MAX_SPEED 150             // 最大速度，降低过冲风险
#define SOFT_STOP_ZONE 40         // 软停止区域，提前开始减速
#define FINE_SPEED_ZONE 15        // 精细调整区域，低速精准控制
#define FINE_MAX_SPEED 50         // 精细调整最大速度
#define ACCEL_LIMIT 20            // 加速度限制，平滑启动和停止
#define STABLE_COUNT 3           // 稳定计数阈值
#define STABLE_DELAY 10           // 稳定状态检查延迟(ms)

int cx_history[FILTER_WINDOW];
int cy_history[FILTER_WINDOW];
int history_index = 0;

static int last_speed_x = 0;      // 上一次X方向速度，用于加速度控制
static int last_speed_y = 0;      // 上一次Y方向速度，用于加速度控制

// 中值滤波（减少异常值影响）
int compare(const void *a, const void *b) { return (*(int*)a - *(int*)b); }

// 初始化滤波历史数组
void init_filter_history() {
    for (int i = 0; i < FILTER_WINDOW; i++) {
        cx_history[i] = cx;
        cy_history[i] = cy;
    }
    history_index = 0;
}

// 中值滤波函数
int median_filter(int new_val, int *history) {
    history[history_index] = new_val;
    history_index = (history_index + 1) % FILTER_WINDOW;
    
    int temp[FILTER_WINDOW];
    memcpy(temp, history, FILTER_WINDOW * sizeof(int));
    qsort(temp, FILTER_WINDOW, sizeof(int), compare);
    
    return temp[FILTER_WINDOW / 2];  // 返回中值
}

// 优化的动态速度计算（S型速度曲线，平滑加减速）
int compute_dynamic_speed(int error) {
    int abs_error = abs(error);
    
    // 死区内不动作
    if (abs_error <= DEAD_ZONE) return 0;
    
    // 精细调整区域，使用更低的最大速度
    if (abs_error <= FINE_SPEED_ZONE) {
        float ratio = (float)(abs_error - DEAD_ZONE) / (FINE_SPEED_ZONE - DEAD_ZONE);
        return MIN_SPEED + (int)((FINE_MAX_SPEED - MIN_SPEED) * ratio);
    }
    
    // 正常调整区域，使用S型曲线（避免线性曲线在临界点的突变）
    float ratio = (float)(abs_error - FINE_SPEED_ZONE) / (SOFT_STOP_ZONE - FINE_SPEED_ZONE);
    if (ratio > 1.0f) ratio = 1.0f;
    
    // S型曲线公式: f(x) = x^2 / (x^2 + (1-x)^2)
    float smooth_ratio = ratio * ratio / (ratio * ratio + (1.0f - ratio) * (1.0f - ratio));
    
    return FINE_MAX_SPEED + (int)((MAX_SPEED - FINE_MAX_SPEED) * smooth_ratio);
}

// 速度平滑控制（限制加速度）
int smooth_speed(int target_speed, int last_speed) {
    int speed_diff = target_speed - last_speed;
    
    // 限制加速度
    if (speed_diff > ACCEL_LIMIT) {
        return last_speed + ACCEL_LIMIT;
    } else if (speed_diff < -ACCEL_LIMIT) {
        return last_speed - ACCEL_LIMIT;
    } else {
        return target_speed;
    }
}

// 停止所有电机
void stop_all_motors() {
    qianjin(0);
    houtui(0);
    youpingyi(0);
    zuopingyi(0);
    Emm_V5_Synchronous_motion(0);
    Delay_ms(10);  // 短暂延迟确保电机停止
}

// 平滑调整位置（修复方向控制逻辑）
void adjust_position_smooth(int error_x, int error_y) {
    // 计算目标速度（仅大小，无方向）
    int target_speed_x = compute_dynamic_speed(error_x);
    int target_speed_y = compute_dynamic_speed(error_y);
    
    // 速度平滑控制（限制加速度）
    int current_speed_x = smooth_speed(target_speed_x, last_speed_x);
    int current_speed_y = smooth_speed(target_speed_y, last_speed_y);
    
    last_speed_x = current_speed_x;
    last_speed_y = current_speed_y;
    
    // X方向控制（根据误差符号决定方向）
    if (current_speed_x > 0) {
        if (error_x > 0) {
            youpingyi(current_speed_x);  // X为正：向左平移（根据摄像头坐标系）
        } else {
            zuopingyi(current_speed_x);  // X为负：向右平移
        }
    } else {
        youpingyi(0);
        zuopingyi(0);  // X方向停止
    }
    
    // Y方向控制（根据误差符号决定方向）
    if (current_speed_y > 0) {
        if (error_y > 0) {
            houtui(current_speed_y);  // Y为正：后退（根据摄像头坐标系）
        } else {
            qianjin(current_speed_y);  // Y为负：前进
        }
    } else {
        qianjin(0);
        houtui(0);  // Y方向停止
    }
    
    // 双方向均停止时同步动作
    if (current_speed_x == 0 && current_speed_y == 0) {
        Emm_V5_Synchronous_motion(0);
    }
}

// 色环对准主函数
void dadadada(int target_x, int target_y) {
    if (colord != 2) return;  // 仅目标颜色时执行
    
    // 初始化滤波和速度历史
    init_filter_history();
    last_speed_x = 0;
    last_speed_y = 0;
    
    int stable_count = 0;
    const int max_attempts = 400;  // 最大尝试次数，防止无限循环
    int attempt_count = 0;
    
    while (1) {
        // 检查是否超过最大尝试次数
        attempt_count++;
        if (attempt_count > max_attempts) {
            stop_all_motors();
            break;
        }
        
        // 计算误差（当前位置与目标位置的差值）
        int error_x = cx - target_x;
        int error_y = cy - target_y;
        
        // 显示误差值（调试用）
        LCD_DisplayNumber(100, 200, error_x, 4);
        LCD_DisplayNumber(100, 250, error_y, 4);
        
        // 中值滤波处理（移除异常值）
        int filtered_x = median_filter(error_x, cx_history);
        int filtered_y = median_filter(error_y, cy_history);
        
        // 判断是否需要调整
        bool adjust_x = abs(filtered_x) > DEAD_ZONE;
        bool adjust_y = abs(filtered_y) > DEAD_ZONE;
        
        // 检查是否完全进入稳定区域
        if (!adjust_x && !adjust_y) {
            stable_count++;
            
            // 连续稳定多次后，进行最终确认
            if (stable_count >= STABLE_COUNT) {
                // 额外确认：延迟后再次检查误差
                Delay_ms(STABLE_DELAY);
                
                int final_error_x = cx - target_x;
                int final_error_y = cy - target_y;
                
                // 使用更小的阈值进行最终确认
                if (abs(final_error_x) <= (DEAD_ZONE * 0.8) && 
                    abs(final_error_y) <= (DEAD_ZONE * 0.8)) {
                    
                    // 执行最终停止
                    stop_all_motors();
                    break;
                } else {
                    stable_count = 0;  // 位置仍有变化，继续调整
                }
            }
        } else {
            stable_count = 0;  // 只要有一个方向需要调整，就重置稳定计数
        }
        
        // 调整位置
        adjust_position_smooth(filtered_x, filtered_y);
        
        // 控制周期（根据误差大小动态调整延迟）
        int delay = (abs(filtered_x) < 15 && abs(filtered_y) < 15) ? 20 : 10;
        Delay_ms(delay);
    }
    
    stop_all_motors();  // 最终停止所有电机
}


//2可以用但会抖动
/****************对准部分****************/
//#define DEAD_ZONE 3         // 死区（停止调整的范围）
//#define FILTER_WINDOW 4  // 滤波窗口大小
//#define MIN_SPEED 15       // 最小速度（略提高，避免动力不足）
//#define MAX_SPEED 180       // 最大速度（降低，减少过冲）
//#define SOFT_STOP_ZONE 60   // 软停止区域（扩大，提前减速）


//int xx,yy;
//		 
//		
//		
//int cx_history[FILTER_WINDOW];
//int cy_history[FILTER_WINDOW];
//int history_index = 0;

//// 新增抓取对准的滤波历史（用于hx/hy）
//int hx_history[FILTER_WINDOW] = {0};
//int hy_history[FILTER_WINDOW] = {0};
//int hx_index = 0;  // 独立管理hx索引
//int hy_index = 0;  // 独立管理hy索引

//// 中值滤波（减少异常值影响）
//int compare(const void *a, const void *b) { return (*(int*)a - *(int*)b); }

//// 初始化滤波历史数组（用首次误差值填充，避免初始0值干扰）
//void init_filter_history(int init_cx, int init_cy) {
//    for (int i = 0; i < FILTER_WINDOW; i++) {
//        cx_history[i] = init_cx;
//        cy_history[i] = init_cy;
//    }
//    history_index = 0;
//}
//int median_filter(int new_val, int *history) {
//    history[history_index] = new_val;
//    history_index = (history_index + 1) % FILTER_WINDOW;

//    int temp[FILTER_WINDOW];
//    memcpy(temp, history, FILTER_WINDOW * sizeof(int));
//    qsort(temp, FILTER_WINDOW, sizeof(int), compare);
//    return temp[FILTER_WINDOW / 2];  // 取中值
//}

// //动态计算速度（远快近慢，适配机械特性）
//int compute_dynamic_speed(int error) {
//    int abs_error = abs(error);
//    if (abs_error <= DEAD_ZONE) return 0;  // 死区内速度为0
//    if (abs_error > SOFT_STOP_ZONE) return MAX_SPEED;
//    
//    // 软停止区内线性调速（误差越小，速度越慢）
//    float ratio = (float)(abs_error - DEAD_ZONE) / (SOFT_STOP_ZONE - DEAD_ZONE);
//    return MIN_SPEED + (int)((MAX_SPEED - MIN_SPEED) * ratio);
//}

// //停止所有电机
//void stop_all_motors() {
//    qianjin(0);
//    houtui(0);
//    youpingyi(0);
//    zuopingyi(0);
//    Emm_V5_Synchronous_motion(0);
//    Delay_ms(20);  // 缩短停止延迟，减少响应滞后
//}


// //平滑调整位置（支持X/Y同时调整，减少启停）
//void adjust_position_smooth(int targetX, int targetY) {
//    // 计算X/Y方向速度（0表示无需调整）
//    int speed_x = compute_dynamic_speed(targetX);
//    int speed_y = compute_dynamic_speed(targetY);

//    // X方向控制（根据符号判断左右）
//    if (speed_x > 0) {
//        if (xx > 0) youpingyi(speed_x);  // X正方向（右移）
//        else zuopingyi(speed_x);              // X负方向（左移）
//    } else {
//        youpingyi(0);
//        zuopingyi(0);  // X方向停止
//    }

//    // Y方向控制（根据符号判断前后）
//    if (speed_y > 0) {
//        if (yy > 0) houtui(speed_y);    // Y正方向（前进）
//        else qianjin(speed_y);                 // Y负方向（后退）
//    } else {
//        qianjin(0);
//        houtui(0);  // Y方向停止
//    }

//    // 仅在两个方向均无需调整时，才同步停止（减少不必要的启停）
//    if (speed_x == 0 && speed_y == 0) {
//        Emm_V5_Synchronous_motion(0);
//    }
//}


//// 新增滑动平均滤波（与中值滤波结合）
//int smooth_filter(int new_val, int *history) {
//    // 先做中值滤波
//    int median = median_filter(new_val, history);
//    // 再做滑动平均（取最近3次中值的平均）
//    static int median_history[3] = {0};
//    static int m_idx = 0;
//    median_history[m_idx] = median;
//    m_idx = (m_idx + 1) % 3;
//    return (median_history[0] + median_history[1] + median_history[2]) / 3;
//}


//// 色环对准函数，对准后还需要再移动偏差(可以使用会抖动)
//void dadadada(int target_x, int target_y) {
//    if (colord != 2) return;  // 仅在目标颜色时执行

//    int stable_count = 0;
//    // 初始化滤波历史（用首次误差值填充，避免初始0值干扰）
//    init_filter_history(cx, cy);  

//    while (1) {
//    int xx = target_x+cx;
//		int yy = target_y+cy;
//    int filtered_cx = smooth_filter(xx, cx_history);
//    int filtered_cy = smooth_filter(yy, cy_history);
//        // 2. 判断是否需要在x、y方向调整（超出±3则调整）
//        bool adjust_x = (abs(filtered_cx) > DEAD_ZONE);
//        bool adjust_y = (abs(filtered_cy) > DEAD_ZONE);
//			
//         int delay_ms = (abs(filtered_cx) < 10 && abs(filtered_cy) < 10) ? 30 : 15;
//        // 3. 检查是否完全进入稳定区域（连续5次双方向稳定）
//        if (!adjust_x && !adjust_y) {
//            stable_count++;
//            if (stable_count >= 3) {
//                stop_all_motors();
//                break;
//            }
//        } else {
//            stable_count = 0;
//        }

//        // 4. 调整位置（传入原始滤波值，由内部判断速度）
//        adjust_position_smooth(filtered_cx, filtered_cy);

//        Delay_ms(15);  // 延长延迟，平衡CPU占用与机械响应
//    }


//     stop_all_motors();
//}




//void dadadada(int target_x, int target_y) {
//    if (colord != 2) return;
//    init_filter_history(cx, cy);
//    int stable_count = 0;

//    while (1) {
//        int error_x = target_x - cx;
//        int error_y = target_y - cy;
//        int filtered_cx = median_filter(error_x, cx_history);
//        int filtered_cy = median_filter(error_y, cy_history);

//        // 动态阻尼：误差较小时降低滤波频率
//        int delay_ms = (abs(filtered_cx) < 10 && abs(filtered_cy) < 10) ? 30 : 15;
//        bool adjust_x = (abs(filtered_cx) > DEAD_ZONE);
//        bool adjust_y = (abs(filtered_cy) > DEAD_ZONE);
//        if (!adjust_x && !adjust_y) {
//            stable_count++;
//            if (stable_count >= 5) break;
//        } else {
//            stable_count = 0;
//        }

//        adjust_position_smooth(filtered_cx, filtered_cy);
//        Delay_ms(delay_ms);
//    }
//    stop_all_motors();
//}





/****************抓取对准模块（滤波优化版）****************/
#define ZHUAQU_DEAD_ZONE 5       // 死区±3（停止阈值）
#define ZHUAQU_LOOSE_ZONE 8        // 宽松区±8（减速阈值）
#define ZHUAQU_FILTER_WINDOW 5     // 滤波窗口大小
#define ZHUAQU_ALPHA 0.4           // EWMA滤波系数
#define ZHUAQU_MIN_SPEED 10        // 最小速度
#define ZHUAQU_MAX_SPEED_HIGH 100  // 高速区最大速度
#define ZHUAQU_MAX_SPEED_LOW 60    // 低速区最大速度

// 滤波历史数组（添加zhuaqu_前缀）
static int zhuaqu_hx_history[ZHUAQU_FILTER_WINDOW] = {0};
static int zhuaqu_hy_history[ZHUAQU_FILTER_WINDOW] = {0};
static int zhuaqu_hx_index = 0;
static int zhuaqu_hy_index = 0;
static float zhuaqu_ewma_x = 0;
static float zhuaqu_ewma_y = 0;

// 中值滤波（添加zhuaqu_前缀）
int zhuaqu_median_filter(int new_val, int* history, int* index) {
    history[*index] = new_val;
    *index = (*index + 1) % ZHUAQU_FILTER_WINDOW;
    
    int sorted[ZHUAQU_FILTER_WINDOW];
    memcpy(sorted, history, ZHUAQU_FILTER_WINDOW * sizeof(int));
    for (int i = 0; i < ZHUAQU_FILTER_WINDOW - 1; i++) {
        for (int j = 0; j < ZHUAQU_FILTER_WINDOW - i - 1; j++) {
            if (sorted[j] > sorted[j + 1]) {
                int temp = sorted[j];
                sorted[j] = sorted[j + 1];
                sorted[j + 1] = temp;
            }
        }
    }
    return sorted[ZHUAQU_FILTER_WINDOW / 2];
}

// 指数加权平均滤波（添加zhuaqu_前缀）
float zhuaqu_ewma_filter(int median_val, float last_ewma) {
    return ZHUAQU_ALPHA * median_val + (1 - ZHUAQU_ALPHA) * last_ewma;
}

// 组合滤波（添加zhuaqu_前缀）
int zhuaqu_combined_filter(int new_val, int* history, int* index, float* last_ewma) {
    int median_val = zhuaqu_median_filter(new_val, history, index);
    *last_ewma = zhuaqu_ewma_filter(median_val, *last_ewma);
    return (int)round(*last_ewma);
}

// 初始化滤波历史（添加zhuaqu_前缀）
void zhuaqu_init_filter_history(int init_error_x, int init_error_y) {
    for (int i = 0; i < ZHUAQU_FILTER_WINDOW; i++) {
        zhuaqu_hx_history[i] = init_error_x;
    }
    zhuaqu_hx_index = 0;
    zhuaqu_ewma_x = init_error_x;
    
    for (int i = 0; i < ZHUAQU_FILTER_WINDOW; i++) {
        zhuaqu_hy_history[i] = init_error_y;
    }
    zhuaqu_hy_index = 0;
    zhuaqu_ewma_y = init_error_y;
}

// 动态速度计算
int zhuaqu_compute_speed(int filtered_error) {
    int abs_error = abs(filtered_error);
    if (abs_error <= ZHUAQU_DEAD_ZONE) return 0;
    
    int max_speed = (abs_error <= ZHUAQU_LOOSE_ZONE) ? 
                   ZHUAQU_MAX_SPEED_LOW : ZHUAQU_MAX_SPEED_HIGH;
    
    if (abs_error <= ZHUAQU_DEAD_ZONE + 2) return ZHUAQU_MIN_SPEED;
    
    float ratio = (float)(abs_error - ZHUAQU_DEAD_ZONE) / 
                 (ZHUAQU_LOOSE_ZONE - ZHUAQU_DEAD_ZONE);
    ratio = (ratio > 1.0f) ? 1.0f : ratio;
    
    return ZHUAQU_MIN_SPEED + (int)((max_speed - ZHUAQU_MIN_SPEED) * ratio);
}

// 平滑调整位置
void zhuaqu_adjust_smooth(int filtered_x, int filtered_y) {
    int speed_x = zhuaqu_compute_speed(filtered_x);
    int speed_y = zhuaqu_compute_speed(filtered_y);

    static int zhuaqu_last_x_dir = 0;
    int curr_x_dir = (filtered_x > 0) ? 1 : (filtered_x < 0 ? -1 : 0);
    if (curr_x_dir != zhuaqu_last_x_dir) {
        youpingyi(0);
        zuopingyi(0);
        Delay_ms(3);
    }
    if (curr_x_dir == 1) {
        youpingyi(speed_x);
        zuopingyi(0);
    } else if (curr_x_dir == -1) {
        zuopingyi(speed_x);
        youpingyi(0);
    } else {
        youpingyi(0);
        zuopingyi(0);
    }
    zhuaqu_last_x_dir = curr_x_dir;

    static int zhuaqu_last_y_dir = 0;
    int curr_y_dir = (filtered_y > 0) ? 1 : (filtered_y < 0 ? -1 : 0);
    if (curr_y_dir != zhuaqu_last_y_dir) {
        qianjin(0);
        houtui(0);
        Delay_ms(3);
    }
    if (curr_y_dir == 1) {
        qianjin(speed_y);
        houtui(0);
    } else if (curr_y_dir == -1) {
        houtui(speed_y);
        qianjin(0);
    } else {
        qianjin(0);
        houtui(0);
    }
    zhuaqu_last_y_dir = curr_y_dir;
}

/**优化后的对准主函数**/
void zdadadada(int target_Kx, int target_Ky) {
    int init_error_x = kx - target_Kx;
    int init_error_y = ky - target_Ky;
    
    zhuaqu_init_filter_history(init_error_x, init_error_y);
    
    int zhuaqu_stable_count = 0;
    while (1) {
        int current_error_x = kx - target_Kx;
        int current_error_y = ky - target_Ky;
        
        int filtered_x = zhuaqu_combined_filter(current_error_x, zhuaqu_hx_history, &zhuaqu_hx_index, &zhuaqu_ewma_x);
        int filtered_y = zhuaqu_combined_filter(current_error_y, zhuaqu_hy_history, &zhuaqu_hy_index, &zhuaqu_ewma_y);
        
        bool stable_x = (abs(filtered_x) <= ZHUAQU_DEAD_ZONE);
        bool stable_y = (abs(filtered_y) <= ZHUAQU_DEAD_ZONE);
        
        if (stable_x && stable_y) {
            zhuaqu_stable_count++;
            if (zhuaqu_stable_count >= 5) {
                stop_all_motors();
                break;
            }
        } else {
            zhuaqu_stable_count = 0;
        }
        
        zhuaqu_adjust_smooth(filtered_x, filtered_y);
        Delay_ms(10);//15
    }
    stop_all_motors();
}












///****************抓取对准模块（优化版）****************/
//#define ZHUAQU_DEAD_ZONE 3         // 严格死区±3（真正停止）
//#define ZHUAQU_NEAR_ZONE 5         // 近目标区±5（进一步减速）
//#define ZHUAQU_LOOSE_ZONE 8        // 宽松死区±8（开始减速）
//#define ZHUAQU_FILTER_WINDOW 8     // 滤波窗口（建议为偶数，取中间两值平均）
//#define ZHUAQU_MIN_SPEED 5         // 最小速度（降低至5，避免近目标时过冲）
//#define ZHUAQU_MAX_SPEED_HIGH 150  // 高速区最大速度
//#define ZHUAQU_MAX_SPEED_LOW 80    // 低速区最大速度
//#define ZHUAQU_MAX_SPEED_NEAR 30   // 近目标区最大速度（新增）
//#define ZHUAQU_ALPHA 0.4           // 指数滤波系数（增大至0.4，减少延迟）
//#define STABLE_REQUIRE 5           // 连续稳定次数（保持5次，确保稳定）

//// 滤波历史数组
//int zhuaqu_hx_history[ZHUAQU_FILTER_WINDOW] = {0};
//int zhuaqu_hy_history[ZHUAQU_FILTER_WINDOW] = {0};
//int zhuaqu_hx_index = 0;
//int zhuaqu_hy_index = 0;

//// 中值滤波比较函数
//int zhuaqu_compare(const void *a, const void *b) {
//    return (*(int*)a - *(int*)b);
//}

//// 指数加权平均滤波（优化：增加动态系数，近目标时降低平滑度）
//int ewma_filter(int new_value, int last_value, bool is_near_target) {
//    // 近目标时增大alpha（减少平滑，提高响应速度）
//    float alpha = is_near_target ? 0.6f : ZHUAQU_ALPHA;
//    return (int)(alpha * new_value + (1 - alpha) * last_value);
//}

//// 动态速度计算（优化：新增近目标区减速）
//int zhuaqu_compute_speed(int error) {
//    int abs_error = abs(error);
//    
//    // 死区内直接返回0（停止）
//    if (abs_error <= ZHUAQU_DEAD_ZONE) {
//        return 0;
//    }
//    
//    // 选择最大速度（近目标区进一步降低速度）
//    int max_speed;
//    if (abs_error <= ZHUAQU_NEAR_ZONE) {
//        max_speed = ZHUAQU_MAX_SPEED_NEAR;  // 近目标区：最慢
//    } else if (abs_error <= ZHUAQU_LOOSE_ZONE) {
//        max_speed = ZHUAQU_MAX_SPEED_LOW;   // 中速区
//    } else {
//        max_speed = ZHUAQU_MAX_SPEED_HIGH;  // 高速区
//    }
//    
//    // 速度映射（确保在近目标区速度更平缓）
//    float ratio;
//    if (abs_error <= ZHUAQU_NEAR_ZONE) {
//        // 近目标区：从DEAD_ZONE到NEAR_ZONE的比例
//        ratio = (float)(abs_error - ZHUAQU_DEAD_ZONE) / 
//               (ZHUAQU_NEAR_ZONE - ZHUAQU_DEAD_ZONE);
//    } else {
//        // 普通区：从NEAR_ZONE到LOOSE_ZONE的比例
//        ratio = (float)(abs_error - ZHUAQU_NEAR_ZONE) / 
//               (ZHUAQU_LOOSE_ZONE - ZHUAQU_NEAR_ZONE);
//        // 限制比例上限为1（超出LOOSE_ZONE时用最大速度）
//        ratio = ratio > 1.0f ? 1.0f : ratio;
//    }
//    
//    // 计算速度（确保不低于最小速度）
//    int speed = ZHUAQU_MIN_SPEED + (int)((max_speed - ZHUAQU_MIN_SPEED) * ratio);
//    return speed < ZHUAQU_MIN_SPEED ? ZHUAQU_MIN_SPEED : speed;
//}

//// 增强版停止函数（带制动缓冲）
//void zhuaqu_stop_motors() {
//    // 先减速到0（避免急停导致的机械抖动）
//    qianjin(0);
//    houtui(0);
//    youpingyi(0);
//    zuopingyi(0);
//    Emm_V5_Synchronous_motion(0);
//    Delay_ms(30);  // 短延时确保电机停稳
//    // 二次确认停止（防止惯性移动）
//    qianjin(0);
//    houtui(0);
//    youpingyi(0);
//    zuopingyi(0);
//}

//// 平滑调整位置（优化方向切换逻辑）
//void zhuaqu_adjust_smooth(int targetX, int targetY) {
//    // 判断是否在近目标区（用于动态滤波）
//    bool is_near_x = (abs(targetX) <= ZHUAQU_NEAR_ZONE);
//    bool is_near_y = (abs(targetY) <= ZHUAQU_NEAR_ZONE);
//    
//    // 计算速度（使用优化后的速度函数）
//    int speed_x = zhuaqu_compute_speed(targetX);
//    int speed_y = zhuaqu_compute_speed(targetY);

//    // X方向控制（优化方向切换的缓冲逻辑）
//    static int last_x_dir = 0;  // 1:右, -1:左, 0:停
//    int curr_x_dir = (targetX > 0) ? 1 : (targetX < 0 ? -1 : 0);
//    if (curr_x_dir != last_x_dir) {
//        if (last_x_dir != 0) {
//            // 方向切换时，根据当前是否在近目标区调整缓冲时间
//            int buffer_delay = is_near_x ? 8 : 5;  // 近目标区缓冲更长（8ms）
//            youpingyi(0);
//            zuopingyi(0);
//            Delay_ms(buffer_delay);
//        }
//        last_x_dir = curr_x_dir;
//    }
//    // 执行X方向移动（近目标区速度更低）
//    if (speed_x > 0) {
//        targetX > 0 ? youpingyi(speed_x) : zuopingyi(speed_x);
//    } else {
//        youpingyi(0);
//        zuopingyi(0);
//    }

//    // Y方向控制（同X方向逻辑）
//    static int last_y_dir = 0;  // 1:前, -1:后, 0:停
//    int curr_y_dir = (targetY > 0) ? 1 : (targetY < 0 ? -1 : 0);
//    if (curr_y_dir != last_y_dir) {
//        if (last_y_dir != 0) {
//            int buffer_delay = is_near_y ? 8 : 5;
//            qianjin(0);
//            houtui(0);
//            Delay_ms(buffer_delay);
//        }
//        last_y_dir = curr_y_dir;
//    }
//    if (speed_y > 0) {
//        targetY > 0 ? qianjin(speed_y) : houtui(speed_y);
//    } else {
//        qianjin(0);
//        houtui(0);
//    }

//    // 双方向均停时同步确认
//    if (speed_x == 0 && speed_y == 0) {
//        Emm_V5_Synchronous_motion(0);
//    }
//}

///**抓取对准主函数（优化版）**/
//void zhuaqu_align(int target_x, int target_y) {
//    int stable_count = 0;
//    // 初始化滤波历史（用当前误差填充，避免初始值为0导致的偏差）
//    int init_error_x = kx - target_x;
//    int init_error_y = ky - target_y;
//    for (int i = 0; i < ZHUAQU_FILTER_WINDOW; i++) {
//        zhuaqu_hx_history[i] = init_error_x;
//        zhuaqu_hy_history[i] = init_error_y;
//    }
//    
//    // 滤波后的值（初始化为当前偏差）
//    int filtered_x = init_error_x;
//    int filtered_y = init_error_y;
//    
//    while (1) {
//        // 1. 计算实时偏差（确保kx、ky是最新的传感器数据）
//        int error_x = kx - target_x;
//        int error_y = ky - target_y;

//        // 2. 中值滤波（优化：取中间两值的平均，减少极端值影响）
//        zhuaqu_hx_history[zhuaqu_hx_index] = error_x;
//        zhuaqu_hx_index = (zhuaqu_hx_index + 1) % ZHUAQU_FILTER_WINDOW;
//        int hx_sorted[ZHUAQU_FILTER_WINDOW];
//        memcpy(hx_sorted, zhuaqu_hx_history, ZHUAQU_FILTER_WINDOW * sizeof(int));
//        qsort(hx_sorted, ZHUAQU_FILTER_WINDOW, sizeof(int), zhuaqu_compare);
//        // 取中间两值的平均（窗口为偶数时更稳定）
//        int median_x = (hx_sorted[ZHUAQU_FILTER_WINDOW/2 - 1] + hx_sorted[ZHUAQU_FILTER_WINDOW/2]) / 2;

//        zhuaqu_hy_history[zhuaqu_hy_index] = error_y;
//        zhuaqu_hy_index = (zhuaqu_hy_index + 1) % ZHUAQU_FILTER_WINDOW;
//        int hy_sorted[ZHUAQU_FILTER_WINDOW];
//        memcpy(hy_sorted, zhuaqu_hy_history, ZHUAQU_FILTER_WINDOW * sizeof(int));
//        qsort(hy_sorted, ZHUAQU_FILTER_WINDOW, sizeof(int), zhuaqu_compare);
//        int median_y = (hy_sorted[ZHUAQU_FILTER_WINDOW/2 - 1] + hy_sorted[ZHUAQU_FILTER_WINDOW/2]) / 2;

//        // 3. 指数加权平均滤波（根据是否近目标动态调整平滑度）
//        bool is_near_x = (abs(median_x) <= ZHUAQU_NEAR_ZONE);
//        bool is_near_y = (abs(median_y) <= ZHUAQU_NEAR_ZONE);
//        filtered_x = ewma_filter(median_x, filtered_x, is_near_x);
//        filtered_y = ewma_filter(median_y, filtered_y, is_near_y);

//        // 4. 调试输出（监控误差变化）
//        printf("error_x=%d, filtered_x=%d | error_y=%d, filtered_y=%d | stable=%d\n",
//               error_x, filtered_x, error_y, filtered_y, stable_count);

//        // 5. 判断是否到达目标区域（严格死区±3）
//        bool is_target_x = (abs(filtered_x) <= ZHUAQU_DEAD_ZONE);
//        bool is_target_y = (abs(filtered_y) <= ZHUAQU_DEAD_ZONE);

//        // 6. 连续稳定计数（必须连续5次达标，确保稳定在死区内）
//        if (is_target_x && is_target_y) {
//            stable_count++;
//            // 稳定次数达标后，先减速到0再完全停止（避免惯性）
//            if (stable_count >= STABLE_REQUIRE) {
//                // 先以最小速度微调一次（确保最终位置准确）
//                zhuaqu_adjust_smooth(filtered_x, filtered_y);
//                Delay_ms(10);
//                // 最终停止并制动
//                zhuaqu_stop_motors();
//                printf("Reached target! Final error: x=%d, y=%d\n", filtered_x, filtered_y);
//                break;
//            }
//        } else {
//            stable_count = 0;  // 任何一帧不达标则重置计数
//        }

//        // 7. 未到达目标时调整（使用优化后的速度计算）
//        if (!is_target_x || !is_target_y) {
//            zhuaqu_adjust_smooth(filtered_x, filtered_y);
//        }

//        // 缩短延迟（提高响应速度，同时避免CPU占用过高）
//        Delay_ms(15);
//    }
//}