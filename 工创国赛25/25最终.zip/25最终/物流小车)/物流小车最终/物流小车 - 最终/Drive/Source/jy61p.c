#include "jy61p.h"
#include "head.h" 

static uint8_t RxBuffer[11];/*接收数据数组*/
static volatile uint8_t RxState = 0;/*接收状态标志位*/
static uint8_t RxIndex = 0;/*接受数组索引*/
float Roll,Pitch,Yaw;/*角度信息，如果只需要整数可以改为整数类型*/


/**
 * @brief       数据包处理函数
 * @param       串口接收的数据RxData
 * @retval      无
 */
void jy61p_ReceiveData(uint8_t RxData)
{
	uint8_t i,sum=0;
	if (RxState == 0)	//等待包头
	{
		if (RxData == 0x55)	//收到包头
		{
			RxBuffer[RxIndex] = RxData;
			RxState = 1;
			RxIndex = 1;	//进入下一状态
		}
	}
	else if (RxState == 1)
	{
		if (RxData == 0x53)	/*判断数据内容，修改这里可以改变要读的数据内容，0x53为角度输出*/
		{
			RxBuffer[RxIndex] = RxData;
			RxState = 2;
			RxIndex = 2;	//进入下一状态
		}
	}
	else if (RxState == 2)	//接收数据
	{
		RxBuffer[RxIndex++] = RxData;
		if(RxIndex == 11)	//接收完成
		{
			for(i=0;i<10;i++)
			{
				sum = sum + RxBuffer[i];	//计算校验和
			}
			if(sum == RxBuffer[10])		//校验成功
			{
				/*计算数据，根据数据内容选择对应的计算公式*/
				Roll = ((int16_t) ((int16_t) RxBuffer[3] << 8 | (int16_t) RxBuffer[2])) / 32768.0f * 180.0f;
				Pitch = ((int16_t) ((int16_t) RxBuffer[5] << 8 | (int16_t) RxBuffer[4])) / 32768.0f * 180.0f;
				Yaw = ((int16_t) ((int16_t) RxBuffer[7] << 8 | (int16_t) RxBuffer[6])) / 32768.0f * 180.0f;

			}
			RxState = 0;
			RxIndex = 0;	//读取完成，回到最初状态，等待包头
		}
	}
}


//顺时针
void clockwise(int spppeed)
{

  Emm_V5_Vel_Control(1,1 , spppeed, 0, 1); Delay_ms(10);
	Emm_V5_Vel_Control(2,1 , spppeed, 0, 1); Delay_ms(10);
	Emm_V5_Vel_Control(3,1 , spppeed, 0, 1); Delay_ms(10);
	Emm_V5_Vel_Control(4,1 , spppeed, 0, 1); Delay_ms(10);
	Emm_V5_Synchronous_motion(0);Delay_ms(20);


}

/*逆时针*/
void anticlockwise(int sppppdddeee)
{
    Emm_V5_Vel_Control(1,0 , sppppdddeee, 0, 1); Delay_ms(10);
	Emm_V5_Vel_Control(2,0 , sppppdddeee, 0, 1); Delay_ms(10);
	Emm_V5_Vel_Control(3,0 , sppppdddeee, 0, 1); Delay_ms(10);
	Emm_V5_Vel_Control(4,0 , sppppdddeee, 0, 1); Delay_ms(10);
	Emm_V5_Synchronous_motion(0);Delay_ms(20);
}

//// 滑动平均滤波器（保持角度平滑）
//#define YAW_FILTER_SIZE 5
//static float yaw_buffer[YAW_FILTER_SIZE] = {0};
//static int yaw_index = 0;
//static int yaw_count = 0;

//// 角度滤波函数
//static float filter_yaw(float new_yaw) {
//    yaw_buffer[yaw_index] = new_yaw;
//    yaw_index = (yaw_index + 1) % YAW_FILTER_SIZE;
//    if (yaw_count < YAW_FILTER_SIZE) yaw_count++;
//    
//    float sum = 0;
//    for (int i = 0; i < yaw_count; i++) {
//        sum += yaw_buffer[i];
//    }
//    return sum / yaw_count; // 平滑滤波后的角度
//}

//// 自动调整角度（最小角度方向旋转）
//void auto_adjust_angle(float target_angle, int max_speed) {
//    // 初始化参数
//    float target = target_angle; // 目标角度（-180~180范围）
//    float current, error;
//    const float deadzone = 1.0f; // 死区（误差小于此值视为到达目标）
//    const float Kp = 1.2f;       // 比例系数（控制速度随误差变化）
//    
//    // 初始化滤波器（首次使用或缓冲区为空时）
//    if (yaw_count == 0) {
//        for (int i = 0; i < YAW_FILTER_SIZE; i++) {
//            yaw_buffer[i] = Yaw; // 用当前角度初始化缓冲区
//        }
//        yaw_count = YAW_FILTER_SIZE;
//    }

//    while (1) {
//        // 1. 读取实时角度并滤波（平滑噪声）
//        float raw_yaw = Yaw; // 假设Yaw是实时角度变量（范围-180~180）
//        current = filter_yaw(raw_yaw); // 滤波后的当前角度
//        
//        // 2. 计算最小角度误差（确保选择最短旋转路径）
//        error = target - current;
//        
//        // 3. 处理跨越±180°边界的情况
//        if (error > 180.0f) {
//            error -= 360.0f;  // 选择顺时针路径
//        } else if (error < -180.0f) {
//            error += 360.0f; // 选择逆时针路径
//        }
//        
//        // 4. 调试输出（可选）
//        // printf("Target: %.1f, Current: %.1f, Error: %.1f, Action: %s\n",
//        //        target, current, error, 
//        //        (error > 0) ? "clockwise(实际逆时针)" : "anticlockwise(实际顺时针)");
//        
//        // 5. 若误差在死区内，停止旋转
//        if (fabsf(error) <= deadzone) {
//            break;
//        }
//        
//        // 6. 计算速度（随误差减小而降低，避免超调）
//        int speed = (int)(Kp * fabsf(error));
//        // 限制最大速度，同时确保速度不为0（避免卡死）
//        if (speed > max_speed) speed = max_speed;
//        if (speed < 10) speed = 10; // 最低速度（可根据电机特性调整）
//        
//        // 7. 根据误差方向选择转动方向（保持函数名与物理行为相反的设定）
//        if (error > 0) {
//            // 误差为正：需要增加角度 → 实际逆时针旋转
//            // 注意：clockwise()函数名错误但物理行为正确（实际是逆时针）
//            clockwise(speed);
//        } else {
//            // 误差为负：需要减少角度 → 实际顺时针旋转
//            // 注意：anticlockwise()函数名错误但物理行为正确（实际是顺时针）
//            anticlockwise(speed);
//        }
//        
//        // 8. 延迟一小段时间，平衡响应速度与稳定性
//        Delay_ms(20);
//    }
//    
//    // 停止所有电机（确保最终状态为静止）
//    clockwise(0);
//    anticlockwise(0);
//}



// 车身角度调整控制器（比例控制）
#define BODY_FILTER_SIZE 5  // 滤波器尺寸
static float body_angle_buffer[BODY_FILTER_SIZE] = {0};
static int body_index = 0;
static int body_count = 0;

// 车身角度滑动平均滤波器
static float filter_body_angle(float new_angle) {
    body_angle_buffer[body_index] = new_angle;
    body_index = (body_index + 1) % BODY_FILTER_SIZE;
    if (body_count < BODY_FILTER_SIZE) body_count++;
    
    float sum = 0;
    for (int i = 0; i < body_count; i++) {
        sum += body_angle_buffer[i];
    }
    return sum / body_count;
}

// 车身旋转控制函数（纯比例控制）
void adjust_body_angle(float target_angle, int max_speed) {
    // 参数配置
    const float deadzone = 0.5f;      // 死区范围 (±1.0°)
    const float Kp = 1.2f;            // 比例系数（比原代码稍高，补偿车身惯性）
    
    // 初始化滤波器
    if (body_count == 0) {
        for (int i = 0; i < BODY_FILTER_SIZE; i++) {
            body_angle_buffer[i] = Yaw; // BodyYaw为车身陀螺仪角度
        }
        body_count = BODY_FILTER_SIZE;
    }

    // 角度调整主循环
    while (1) {
        // 1. 获取并滤波当前车身角度
        float current = filter_body_angle(Yaw);
        
        // 2. 计算最小路径角度误差
        float error = target_angle - current;
        
        // 3. 处理角度跨越±180°边界
        if (error > 180.0f) {
            error -= 360.0f;
        } else if (error < -180.0f) {
            error += 360.0f;
        }
        
        // 4. 检查是否到达目标
        if (fabsf(error) <= deadzone) {
            break;
        }
        
        // 5. 计算比例控制输出速度
        int speed = (int)(Kp * fabsf(error));
        
        // 6. 速度限幅
        if (speed > max_speed) speed = max_speed;
        if (speed < 15) speed = 15;  // 最小速度确保车身能转动
        
        // 7. 控制车身旋转
        if (error > 0) {
            // 需要逆时针旋转车身
           clockwise(speed);  // 实际逆时针旋转函数
        } else {
            // 需要顺时针旋转车身
            anticlockwise(speed);   // 实际顺时针旋转函数
        }
        
        // 8. 适当延时（20ms典型值）
        Delay_ms(20);
    }
    
    // 停止车身旋转
    clockwise(0);
    anticlockwise(0);
}

