 /***
	************************************************************************************
	*	@file  	usart.c
	*	@brief   usart 接口相关函数
   ************************************************************************************
   *  @description
	*  功能：摄像头识别获得色块以及色环的数据
	*  初始化USART2的引脚 PA2/PA3，
	*  配置USART1工作在收发模式、数位8位、停止位1位、无校验、不使用硬件控制流控制，
	*  串口的波特率设置为115200，若需要更改波特率直接修改usart.h里的宏定义USART1_BaudRate。
	*  重定义fputc函数,用以支持使用printf函数打印数据
	*
	************************************************************************************
***/
//#include "head.h" 
//#include "stm32f10x.h"
//#include <string.h>
//#include <jy61p.h>
//#include <stdio.h>
//#include "misc.h"
//// 数据帧格式定义
//#define FRAME_HEADER_COLOR_RING  0xFE    // 色环数据帧头
//#define FRAME_HEADER_COLOR_BLOCK 0xFD    // 色块数据帧头
//#define FRAME_TAIL               0xFF    // 帧尾
//#define FRAME_LEN_COLOR_RING     5       // 色环数据帧长度：0xFE + 颜色 + x + y + 0xFF
//#define FRAME_LEN_COLOR_BLOCK    8       // 色块数据帧长度：0xFD + 红代码 + 红扇区 + 绿代码 + 绿扇区 + 蓝代码 + 蓝扇区 + 0xFC

//// 颜色代号定义
//#define COLOR_RED                1
//#define COLOR_GREEN              2
//#define COLOR_BLUE               3

//// 扇区编号定义
//#define SECTOR_4                 4
//#define SECTOR_5                 5
//#define SECTOR_6                 6

//// 全局变量定义
//uint8_t rxBuffer[FRAME_LEN_COLOR_BLOCK];  // 接收缓冲区（最大长度）
//uint8_t rxIndex = 0;                      // 接收索引
//uint8_t rxState = 0;                      // 接收状态机状态
//uint8_t currentFrameType = 0;             // 当前帧类型（0:未识别，1:色环，2:色块）
//uint8_t debounceCount = 0;                // 防抖计数器
//#define DEBOUNCE_TIMES           3       // 防抖次数

//// 色环数据存储
//extern uint8_t colord;                       // 色环颜色代号
//extern int8_t cx , cy ;                    // 色环X、Y坐标

//// 色块数据存储
//extern uint8_t rc , rd ;                   // 红色块代号及扇区
//extern uint8_t gc , gd ;                   // 绿色块代号及扇区
//extern uint8_t bc , bd ;                   // 蓝色块代号及扇区

//int8_t twos_complement_to_decimal(uint8_t twos_comp);                     // 补码转十进制

//// 补码转十进制有符号整数
//int8_t twos_complement_to_decimal(uint8_t twos_comp) {
//    return (int8_t)twos_comp;  // C语言自动处理补码转换
//}

//// 更新LCD显示
//void updateLCD(void) {
//    char displayBuf[50];
//    
//		LCD_DisplayNumber(120, 50, rc, 1);  // 红色
//		LCD_DisplayNumber(140, 50, rd, 1);  // 所在位置扇区
//		LCD_DisplayNumber(120, 70, gc, 1);  // 绿色
//		LCD_DisplayNumber(140, 70, gd, 1);  // 绿色所在位置扇区
//		LCD_DisplayNumber(120, 90, bc, 1);  // 蓝色
//		LCD_DisplayNumber(140, 90, bd, 1);  // 蓝色所在位置扇区 
//		LCD_DisplayNumber(20, 50, colord, 1);  // 个位数
//		LCD_DisplayNumber(20, 70, cx, 5);  // 带符号4位数
//		LCD_DisplayNumber(20, 90, cy, 5);  // 带符号4位数	
//}

//// USART2初始化
//void USART2_GPIO_Config(void) {
//    GPIO_InitTypeDef GPIO_InitStructure;
//    USART_InitTypeDef USART_InitStructure;
//    NVIC_InitTypeDef NVIC_InitStructure;

//    // 使能时钟
//    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
//    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

//    // 配置USART2引脚
//    GPIO_InitStructure.GPIO_Pin = USART2_TX_PIN	;        // TX
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
//    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
//    GPIO_Init(GPIOA, &GPIO_InitStructure);

//    GPIO_InitStructure.GPIO_Pin = USART2_RX_PIN	;        // RX
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
//    GPIO_Init(GPIOA, &GPIO_InitStructure);

//    // 配置USART参数
//    USART_InitStructure.USART_BaudRate = USART2_BaudRate;
//    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
//    USART_InitStructure.USART_StopBits = USART_StopBits_1;
//    USART_InitStructure.USART_Parity = USART_Parity_No;
//    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
//    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
//    USART_Init(USART2, &USART_InitStructure);

//    // 使能接收中断
//    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
//    
//    // 配置NVIC
//    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//    NVIC_Init(&NVIC_InitStructure);

//    USART_Cmd(USART2, ENABLE);
//}

//// USART2中断处理函数
//void USART2_IRQHandler(void) {
//    if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
//        uint8_t receivedData = USART_ReceiveData(USART2);
//        
//        switch (rxState) {
//            case 0: // 等待帧头
//                rxIndex = 0;
//                rxBuffer[rxIndex++] = receivedData;
//                
//                // 检测帧头类型
//                if (receivedData == FRAME_HEADER_COLOR_RING) {
//                    currentFrameType = 1;
//                    rxState = 1;
//                } else if (receivedData == FRAME_HEADER_COLOR_BLOCK) {
//                    currentFrameType = 2;
//                    rxState = 1;
//                } else {
//                    rxState = 0;
//                }
//                break;
//                
//            case 1: // 接收数据
//                rxBuffer[rxIndex++] = receivedData;
//                
//                // 根据帧类型判断接收长度
//                if (currentFrameType == 1 && rxIndex >= FRAME_LEN_COLOR_RING) {
//                    // 色环数据帧解析
//                    if (rxBuffer[rxIndex-1] == FRAME_TAIL) {
//                        colord = rxBuffer[1];
//                        cx = twos_complement_to_decimal(rxBuffer[2]);
//                        cy = twos_complement_to_decimal(rxBuffer[3]);
//                        updateLCD();
//                    }
//                    rxState = 0;
//                    rxIndex = 0;
//                } else if (currentFrameType == 2 && rxIndex >= FRAME_LEN_COLOR_BLOCK) {
//                    // 色块数据帧解析
//                    if (rxBuffer[rxIndex-1] == 0xFC) {  // 色块帧尾为0xFC
//                        rc = rxBuffer[1];  // 红色代码
//                        rd = rxBuffer[2];  // 红色扇区
//                        gc = rxBuffer[3];  // 绿色代码
//                        gd = rxBuffer[4];  // 绿色扇区
//                        bc = rxBuffer[5];  // 蓝色代码
//                        bd = rxBuffer[6];  // 蓝色扇区
//                        updateLCD();
//                    }
//                    rxState = 0;
//                    rxIndex = 0;
//                }
//                break;
//                
//            default:
//                rxState = 0;
//                rxIndex = 0;
//                break;
//        }
//        
//        USART_ClearITPendingBit(USART2, USART_IT_RXNE);
//    }
//}


#include "head.h" 
#include "stm32f10x.h"
#include <string.h>
#include <jy61p.h>
#include <stdio.h>
#include "misc.h"
// 数据帧格式定义
#define FRAME_HEADER_COLOR_RING  0xFE    // 色环数据帧头
#define FRAME_HEADER_COLOR_BLOCK 0xFD    // 色块数据帧头
#define FRAME_TAIL               0xFF    // 帧尾
#define FRAME_LEN_COLOR_RING     5       // 色环数据帧长度：0xFE + 颜色 + x + y + 0xFF
#define FRAME_LEN_COLOR_BLOCK    10      // 色块数据帧长度：0xFD + 红代码 + 红扇区 + 绿代码 + 绿扇区 + 蓝代码 + 蓝扇区 + kx + ky + 0xFC

// 颜色代号定义
#define COLOR_RED                1
#define COLOR_GREEN              2
#define COLOR_BLUE               3

// 扇区编号定义
#define SECTOR_4                 4
#define SECTOR_5                 5
#define SECTOR_6                 6

// 全局变量定义
uint8_t rxBuffer[FRAME_LEN_COLOR_BLOCK];  // 接收缓冲区（最大长度）
uint8_t rxIndex = 0;                      // 接收索引
uint8_t rxState = 0;                      // 接收状态机状态
uint8_t currentFrameType = 0;             // 当前帧类型（0:未识别，1:色环，2:色块）
uint8_t debounceCount = 0;                // 防抖计数器
#define DEBOUNCE_TIMES           3       // 防抖次数

// 色环数据存储
extern uint8_t colord;                       // 色环颜色代号
extern int8_t cx , cy ;                    // 色环X、Y坐标

// 色块数据存储
extern uint8_t rc , rd ;                   // 红色块代号及扇区
extern uint8_t gc , gd ;                   // 绿色块代号及扇区
extern uint8_t bc , bd ;                   // 蓝色块代号及扇区
extern int8_t kx, ky;                      // 新增：色块坐标

int8_t twos_complement_to_decimal(uint8_t twos_comp);                     // 补码转十进制

// 补码转十进制有符号整数
int8_t twos_complement_to_decimal(uint8_t twos_comp) {
    return (int8_t)twos_comp;  // C语言自动处理补码转换
}

// 更新LCD显示
void updateLCD(void) {
    char displayBuf[50];
    
    LCD_DisplayNumber(120, 50, rc, 1);  // 红色
    LCD_DisplayNumber(140, 50, rd, 1);  // 所在位置扇区
    LCD_DisplayNumber(120, 70, gc, 1);  // 绿色
    LCD_DisplayNumber(140, 70, gd, 1);  // 绿色所在位置扇区
    LCD_DisplayNumber(120, 90, bc, 1);  // 蓝色
    LCD_DisplayNumber(140, 90, bd, 1);  // 蓝色所在位置扇区 
    LCD_DisplayNumber(20, 50, colord, 1);  // 个位数
    LCD_DisplayNumber(20, 70, cx, 5);  // 带符号4位数
    LCD_DisplayNumber(20, 90, cy, 5);  // 带符号4位数
    LCD_DisplayNumber(120, 110, kx, 5); // 新增：色块kx坐标
    LCD_DisplayNumber(140, 180, ky, 5); // 新增：色块ky坐标	
}

// USART2初始化
void USART2_GPIO_Config(void) {
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    // 使能时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    // 配置USART2引脚
    GPIO_InitStructure.GPIO_Pin = USART2_TX_PIN	;        // TX
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = USART2_RX_PIN	;        // RX
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 配置USART参数
    USART_InitStructure.USART_BaudRate = USART2_BaudRate;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART2, &USART_InitStructure);

    // 使能接收中断
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    
    // 配置NVIC
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART2, ENABLE);
}

// USART2中断处理函数
void USART2_IRQHandler(void) {
    if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET) {
        uint8_t receivedData = USART_ReceiveData(USART2);
        
        switch (rxState) {
            case 0: // 等待帧头
                rxIndex = 0;
                rxBuffer[rxIndex++] = receivedData;
                
                // 检测帧头类型
                if (receivedData == FRAME_HEADER_COLOR_RING) {
                    currentFrameType = 1;
                    rxState = 1;
                } else if (receivedData == FRAME_HEADER_COLOR_BLOCK) {
                    currentFrameType = 2;
                    rxState = 1;
                } else {
                    rxState = 0;
                }
                break;
                
            case 1: // 接收数据
                rxBuffer[rxIndex++] = receivedData;
                
                // 根据帧类型判断接收长度
                if (currentFrameType == 1 && rxIndex >= FRAME_LEN_COLOR_RING) {
                    // 色环数据帧解析
                    if (rxBuffer[rxIndex-1] == FRAME_TAIL) {
                        colord = rxBuffer[1];
                        cx = twos_complement_to_decimal(rxBuffer[2]);
                        cy = twos_complement_to_decimal(rxBuffer[3]);
                        updateLCD();
                    }
                    rxState = 0;
                    rxIndex = 0;
                } else if (currentFrameType == 2 && rxIndex >= FRAME_LEN_COLOR_BLOCK) {
                    // 色块数据帧解析
                    if (rxBuffer[rxIndex-1] == 0xFC) {  // 色块帧尾为0xFC
                        rc = rxBuffer[1];  // 红色代码
                        rd = rxBuffer[2];  // 红色扇区
                        gc = rxBuffer[3];  // 绿色代码
                        gd = rxBuffer[4];  // 绿色扇区
                        bc = rxBuffer[5];  // 蓝色代码
                        bd = rxBuffer[6];  // 蓝色扇区
                        kx = twos_complement_to_decimal(rxBuffer[7]); // 新增：kx坐标
                        ky = twos_complement_to_decimal(rxBuffer[8]); // 新增：ky坐标
                        updateLCD();
                    }
                    rxState = 0;
                    rxIndex = 0;
                }
                break;
                
            default:
                rxState = 0;
                rxIndex = 0;
                break;
        }
        
        USART_ClearITPendingBit(USART2, USART_IT_RXNE);
    }
}