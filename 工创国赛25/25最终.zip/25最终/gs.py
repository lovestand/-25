import cv2
import numpy as np
import serial
import time
from collections import deque

# -------------------------- 参数配置 --------------------------
CAMERA_ID = 0                  # 摄像头设备ID（0为默认摄像头）
FRAME_WIDTH = 1280             # 图像宽度（像素）
FRAME_HEIGHT = 720             # 图像高度（像素）
MIN_DIAMETER_MM = 48           # 最小检测直径（mm）
MAX_DIAMETER_MM =  92          # 最大检测直径（mm）
PIXELS_PER_MM = 2.5            # 像素/毫米比例（需根据实际摄像头校准）
# 霍夫圆检测参数（需根据实际画面调整）
HOUGH_DP = 1.2                 # 累加器分辨率与图像分辨率的反比
HOUGH_MIN_DIST = 12000         # 检测到的圆之间的最小距
HOUGH_PARAM1 = 100             # Canny边缘检测的高阈值
HOUGH_PARAM2 = 80              # 累加器阈值（越小检测到的圆越多）
# 圆环检测颜色范围（HSV空间）
COLOR_RANGES = {
    'red': [
        (np.array([0, 60, 60]), np.array([10, 255, 255])),   # 红色低区间（0-10度）
        (np.array([160, 60, 60]), np.array([180, 255, 255]))  # 红色高区间（160-180度）
    ],
    'green': [
        (np.array([30, 60, 60]), np.array([80, 255, 255]))    # 绿色区间
    ],
    'blue': [
        (np.array([100, 60, 60]), np.array([140, 255, 255]))   # 蓝色区间
    ]
}
# 色块检测颜色范围（独立配置，不与圆环检测合并）
BLOCK_COLOR_RANGES = {
    'red': [
        (np.array([0, 60, 60]), np.array([10, 255, 255])),
        (np.array([160, 60, 60]), np.array([180, 255, 255]))
    ],
    'green': [
        (np.array([40, 60, 60]), np.array([80, 255, 255]))
    ],
    'blue': [
        (np.array([100, 60, 60]), np.array([140, 255, 255]))
    ]
}
SERIAL_PORT = "/dev/ttyAMA0"  # 树莓派串口端口，根据实际情况修改
SERIAL_BAUDRATE = 9600
FILTER_WINDOW = 5             # 滤波窗口大小
STABLE_FRAMES = 3             # 新增：物块连续稳定帧数阈值（达到该帧数后认为停止转动）
# 颜色代号
COLOR_CODE = {'red': 1, 'green': 2, 'blue': 3}
# 扇区配置（4扇区位于下方）
SECTOR_ANGLES = 120           # 扇区分割角度
SECTOR_NAMES = [4, 5, 6]      # 扇区编号（4:下方, 5:右侧, 6:左侧）
# ------------------------------------------------------------

def init_camera():
    """初始化摄像头并设置分辨率"""
    cap = cv2.VideoCapture(CAMERA_ID)
    if not cap.isOpened():
        raise ValueError("无法打开摄像头，请检查设备连接")
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)
    return cap

def pixel_to_mm(pixel):
    """像素到毫米的转换（根据PIXELS_PER_MM比例）"""
    return pixel / PIXELS_PER_MM

def mm_to_pixel(mm):
    """毫米到像素的转换（根据PIXELS_PER_MM比例）"""
    return int(mm * PIXELS_PER_MM)

def detect_circles(frame):
    """检测符合直径范围的圆环"""
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (9, 9), 2)
    circles = cv2.HoughCircles(
        blurred,
        cv2.HOUGH_GRADIENT,
        dp=HOUGH_DP,
        minDist=HOUGH_MIN_DIST,
        param1=HOUGH_PARAM1,
        param2=HOUGH_PARAM2,
        minRadius=mm_to_pixel(MIN_DIAMETER_MM/2),
        maxRadius=mm_to_pixel(MAX_DIAMETER_MM/2)
    )
    return circles

def get_sector(x, y):
    """计算点(x,y)所在的扇区（4扇区位于下方）"""
    center_x, center_y = FRAME_WIDTH//2, FRAME_HEIGHT//2
    dx = x - center_x
    dy = y - center_y  # 保持y轴向下为正（不反转）
    
    # 计算相对于中心点的角度（-180到180度）
    angle = np.degrees(np.arctan2(dy, dx))
    
    # 调整角度范围为0-360度
    angle = (angle + 360) % 360
    
    # 扇区划分逻辑（4:下方, 5:右侧, 6:左侧）
    # 扇区4: 30度-150度（下方区域）
    # 扇区5: 150度-270度（右侧区域）
    # 扇区6: 270度-30度（左侧区域）
    if 30 <= angle < 150:
        return SECTOR_NAMES[0]  # 扇区4（下方）
    elif 150 <= angle < 270:
        return SECTOR_NAMES[1]  # 扇区5（右侧）
    else:
        return SECTOR_NAMES[2]  # 扇区6（左侧）

def detect_color_blocks(frame, color_ranges, ser):
    """检测色块并按顺序发送红、绿、蓝的代号和扇区，未检测到设为0"""
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    detected = False
    block_order = []
    # 初始化所有颜色的扇区数据为0（未检测到）
    red_code, red_sector = 0, 0
    green_code, green_sector = 0, 0
    blue_code, blue_sector = 0, 0
    for color_name, ranges in color_ranges.items():
        if color_name == 'red':
            mask1 = cv2.inRange(hsv, ranges[0][0], ranges[0][1])
            mask2 = cv2.inRange(hsv, ranges[1][0], ranges[1][1])
            mask = cv2.bitwise_or(mask1, mask2)
        else:
            mask = cv2.inRange(hsv, ranges[0][0], ranges[0][1])
        kernel = np.ones((3,3), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        max_area = 0
        main_contour = None
        # 找到最大的色块
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > 700 and area > max_area:
                max_area = area
                main_contour = cnt
        if main_contour is not None:
            x, y, w, h = cv2.boundingRect(main_contour)
            cv2.rectangle(frame, (x,y), (x+w,y+h), (0,255,0), 2)
            # 计算色块中心点
            cx = x + w//2
            cy = y + h//2
            # 计算扇区
            sector = get_sector(cx, cy)
            if color_name == 'red':
                red_code = COLOR_CODE[color_name]
                red_sector = sector
            elif color_name == 'green':
                green_code = COLOR_CODE[color_name]
                green_sector = sector
            elif color_name == 'blue':
                blue_code = COLOR_CODE[color_name]
                blue_sector = sector
            block_order.append(color_name)
            # 显示扇区信息
            info = f"{color_name}: C{COLOR_CODE[color_name]} S{sector}"
            cv2.putText(frame, info, (x, y-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)
            detected = True
    # 串口数据发送逻辑移到主循环
    # 返回色块顺序（如无色块则返回None）
    if len(block_order) > 0:
        return frame, block_order
    else:
        return frame, None

def draw_sector_lines(frame):
    """绘制三个扇区的分割线（4扇区位于下方，延长分隔线至画面边缘）"""
    center_x, center_y = FRAME_WIDTH//2, FRAME_HEIGHT//2
    
    # 计算从中心到画面四个角落的最长距离（确保线条覆盖整个画面）
    max_distance = int(np.sqrt((FRAME_WIDTH**2) + (FRAME_HEIGHT**2)))
    
    # 绘制三条分割线（从中心延伸至画面边缘）
    # 左侧分割线（30度）
    angle_left = 30
    rad_left = np.radians(angle_left)
    end_x_left = int(center_x + max_distance * np.cos(rad_left))
    end_y_left = int(center_y + max_distance * np.sin(rad_left))
    cv2.line(frame, (center_x, center_y), (end_x_left, end_y_left), (255, 255, 255), 2)
    
    # 右侧分割线（150度）
    angle_right = 150
    rad_right = np.radians(angle_right)
    end_x_right = int(center_x + max_distance * np.cos(rad_right))
    end_y_right = int(center_y + max_distance * np.sin(rad_right))
    cv2.line(frame, (center_x, center_y), (end_x_right, end_y_right), (255, 255, 255), 2)
    
    # 底部辅助线（90度，仅用于视觉参考）
    cv2.line(frame, (center_x, center_y), 
             (center_x, FRAME_HEIGHT), (255, 255, 255), 1)
    
    # 标记扇区编号
    # 扇区4: 下方区域（30-150度）
    text_x4 = int(center_x + (max_distance*0.3) * np.cos(np.radians(90)))
    text_y4 = int(center_y + (max_distance*0.3) * np.sin(np.radians(90)))
    cv2.putText(frame, f"{SECTOR_NAMES[0]}", (text_x4, text_y4),
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)
    
    # 扇区5: 右侧区域（150-270度）
    text_x5 = int(center_x + (max_distance*0.3) * np.cos(np.radians(210)))
    text_y5 = int(center_y + (max_distance*0.3) * np.sin(np.radians(210)))
    cv2.putText(frame, f"{SECTOR_NAMES[1]}", (text_x5, text_y5),
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)
    
    # 扇区6: 左侧区域（270-30度）
    text_x6 = int(center_x + (max_distance*0.3) * np.cos(np.radians(330)))
    text_y6 = int(center_y + (max_distance*0.3) * np.sin(np.radians(330)))
    cv2.putText(frame, f"{SECTOR_NAMES[2]}", (text_x6, text_y6),
                cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)

def filter_center(center_queue, new_x, new_y):
    """对圆心坐标进行滑动平均滤波"""
    center_queue.append((new_x, new_y))
    if len(center_queue) > FILTER_WINDOW:
        center_queue.popleft()
    xs = [item[0] for item in center_queue]
    ys = [item[1] for item in center_queue]
    avg_x = sum(xs) / len(xs)
    avg_y = sum(ys) / len(ys)
    return avg_x, avg_y

def int_to_hex_bytes(val):
    """将有符号整数(-127~127)转换为1字节十六进制（补码）"""
    return val & 0xFF

def detect_color_blocks_for_send(frame, color_ranges):
    """检测色块并返回顺序和数据（含区域4偏移量）"""
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    detected = False
    block_order = []
    # 初始化所有颜色的扇区数据为0（未检测到）
    red_code, red_sector, red_x, red_y = 0, 0, 0, 0  # 新增坐标变量初始化
    green_code, green_sector, green_x, green_y = 0, 0, 0, 0  # 新增坐标变量初始化
    blue_code, blue_sector, blue_x, blue_y = 0, 0, 0, 0  # 新增坐标变量初始化
    # 新增：区域4偏移量（初始为0）
    sector4_x, sector4_y = 0, 0
    max_sector4_area = 0  # 记录区域4色块的最大面积（取最大的色块）
    center_x = FRAME_WIDTH // 2  # 画面中心x坐标（原点）
    center_y = FRAME_HEIGHT // 2  # 画面中心y坐标（原点）

    for color_name, ranges in color_ranges.items():
        if color_name == 'red':
            mask1 = cv2.inRange(hsv, ranges[0][0], ranges[0][1])
            mask2 = cv2.inRange(hsv, ranges[1][0], ranges[1][1])
            mask = cv2.bitwise_or(mask1, mask2)
        else:
            mask = cv2.inRange(hsv, ranges[0][0], ranges[0][1])
        kernel = np.ones((3,3), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        max_area = 0
        main_contour = None
        # 找到最大的色块
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > 700 and area > max_area:
                max_area = area
                main_contour = cnt
        if main_contour is not None:
            x, y, w, h = cv2.boundingRect(main_contour)
            cv2.rectangle(frame, (x,y), (x+w,y+h), (0,255,0), 2)
            # 计算色块中心点（像素坐标）
            cx = x + w//2
            cy = y + h//2
            # 计算扇区
            sector = get_sector(cx, cy)
            # 记录颜色代号和扇区（所有区域）
            if color_name == 'red':
                red_code = COLOR_CODE[color_name]
                red_sector = sector
                red_x = pixel_to_mm(cx - center_x)  # 计算相对于中心的x偏移（毫米）
                red_y = pixel_to_mm(cy - center_y)  # 计算相对于中心的y偏移（毫米）
            elif color_name == 'green':
                green_code = COLOR_CODE[color_name]
                green_sector = sector
                green_x = pixel_to_mm(cx - center_x)
                green_y = pixel_to_mm(cy - center_y)
            elif color_name == 'blue':
                blue_code = COLOR_CODE[color_name]
                blue_sector = sector
                blue_x = pixel_to_mm(cx - center_x)
                blue_y = pixel_to_mm(cy - center_y)
            block_order.append(color_name)
            # 显示扇区信息
            info = f"{color_name}: C{COLOR_CODE[color_name]} S{sector}"
            cv2.putText(frame, info, (x, y-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,0), 2)
            detected = True

            # 新增：计算区域4偏移量（仅保留最大面积的色块）
            if sector == SECTOR_NAMES[0]:  # 是区域4的色块
                # 计算相对于画面中心的像素偏移量（转换为毫米）
                offset_x_pixel = cx - center_x
                offset_y_pixel = cy - center_y
                offset_x_mm = pixel_to_mm(offset_x_pixel)
                offset_y_mm = pixel_to_mm(offset_y_pixel)
                x_int = max(-127, min(127, int(round(offset_x_mm))))  # 限制在-127~127
                y_int = max(-127, min(127, int(round(offset_y_mm))))  # 限制在-127~127
                # 仅保留最大面积的区域4色块的偏移量
                if max_area > max_sector4_area:
                    max_sector4_area = max_area
                    sector4_x = x_int
                    sector4_y = y_int
    
    # 生成完整的block_data字典（无论是否检测到色块）
    block_data = {
        'red_code': red_code,
        'red_sector': red_sector,
        'red_x': red_x,  # 新增坐标字段（毫米）
        'red_y': red_y,  # 新增坐标字段（毫米）
        'green_code': green_code,
        'green_sector': green_sector,
        'green_x': green_x,  # 新增坐标字段（毫米）
        'green_y': green_y,  # 新增坐标字段（毫米）
        'blue_code': blue_code,
        'blue_sector': blue_sector,
        'blue_x': blue_x,  # 新增坐标字段（毫米）
        'blue_y': blue_y,  # 新增坐标字段（毫米）
        'sector4_x': sector4_x,  # 扇区4色块x坐标（毫米，已转换为整数）
        'sector4_y': sector4_y   # 扇区4色块y坐标（毫米，已转换为整数）
    }
    
    # 返回处理后的帧、色块顺序和数据
    return frame, block_order, block_data

def main():
    # 初始化串口
    try:
        ser = serial.Serial(SERIAL_PORT, SERIAL_BAUDRATE, timeout=1)
        time.sleep(2)
    except Exception as e:
        print("串口初始化失败：", e)
        ser = None

    cap = init_camera()
    center_x, center_y = FRAME_WIDTH//2, FRAME_HEIGHT//2

    # 用于滤波的队列
    center_queue = deque()

    # 修改：新增稳定计数器和上一次顺序记录
    last_block_order = None
    stable_count = 0  # 记录当前色块顺序连续稳定的帧数

    while True:
        ret, frame = cap.read()
        if not ret:
            print("无法获取视频帧")
            break

        detected_circle = False
        green_circle_detected = False
        green_circle_data = None

        # 绘制扇区分割线
        draw_sector_lines(frame)

        # 优先检测绿色色环
        color = 'green'
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
        for (low, high) in COLOR_RANGES[color]:
            sub_mask = cv2.inRange(hsv, low, high)
            mask = cv2.bitwise_or(mask, sub_mask)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3,3), np.uint8))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((5,5), np.uint8))
        masked_frame = cv2.bitwise_and(frame, frame, mask=mask)
        circles = detect_circles(masked_frame)
        if circles is not None:
            circles = np.uint16(np.around(circles))
            draw_color = (0, 255, 0)  # 绿色
            for (x, y, r) in circles[0, :]:
                # 数据范围检查
                if not (0 <= x < FRAME_WIDTH and 0 <= y < FRAME_HEIGHT and r > 0):
                    continue
                diameter_mm = pixel_to_mm(r * 2)
                if not (MIN_DIAMETER_MM <= diameter_mm <= MAX_DIAMETER_MM):
                    continue
                offset_x = pixel_to_mm(x - center_x)
                offset_y = pixel_to_mm(y - center_y)
                filtered_x_mm, filtered_y_mm = filter_center(
                    center_queue, pixel_to_mm(x - center_x), pixel_to_mm(y - center_y)
                )
                cv2.circle(frame, (x, y), r, draw_color, 2)
                cv2.circle(frame, (x, y), 2, draw_color, 3)
                info = f"{color.upper()}: D:{diameter_mm:.1f}mm X:{filtered_x_mm:.1f}mm Y:{filtered_y_mm:.1f}mm"
                cv2.putText(frame, info, (x-70, y-10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
                # 保存绿色色环数据
                green_circle_detected = True
                green_circle_data = {
                    'code': COLOR_CODE[color],
                    'x': filtered_x_mm,
                    'y': filtered_y_mm,
                    'x_int': max(-127, min(127, int(round(filtered_x_mm)))),
                    'y_int': max(-127, min(127, int(round(filtered_y_mm))))
                }
                # 只处理第一个绿色色环
                break
        # 如果检测到绿色色环，直接使用其数据
        if green_circle_detected:
            detected_circle = True
            # 串口发送绿色色环数据
            if ser is not None:
                arr = [0xFE, green_circle_data['code'], 
                       int_to_hex_bytes(green_circle_data['x_int']), 
                       int_to_hex_bytes(green_circle_data['y_int']), 0xFF]
                ser.write(bytes(arr))
                print(f"发送绿色色环数据: {arr}")
        # 如果没有检测到绿色色环，再检测其他颜色
        if not green_circle_detected:
            for color in ['red', 'blue']:
                hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
                mask = np.zeros(hsv.shape[:2], dtype=np.uint8)
                for (low, high) in COLOR_RANGES[color]:
                    sub_mask = cv2.inRange(hsv, low, high)
                    mask = cv2.bitwise_or(mask, sub_mask)
                mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3,3), np.uint8))
                mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((5,5), np.uint8))
                masked_frame = cv2.bitwise_and(frame, frame, mask=mask)
                circles = detect_circles(masked_frame)
                if circles is not None:
                    detected_circle = True
                    circles = np.uint16(np.around(circles))
                    draw_color = {
                        'red': (0, 0, 255),
                        'blue': (255, 0, 0)
                    }[color]
                    for (x, y, r) in circles[0, :]:
                        # 数据范围检查
                        if not (0 <= x < FRAME_WIDTH and 0 <= y < FRAME_HEIGHT and r > 0):
                            continue
                        diameter_mm = pixel_to_mm(r * 2)
                        if not (MIN_DIAMETER_MM <= diameter_mm <= MAX_DIAMETER_MM):
                            continue
                        offset_x = pixel_to_mm(x - center_x)
                        offset_y = pixel_to_mm(y - center_y)
                        filtered_x_mm, filtered_y_mm = filter_center(
                            center_queue, pixel_to_mm(x - center_x), pixel_to_mm(y - center_y)
                        )
                        cv2.circle(frame, (x, y), r, draw_color, 2)
                        cv2.circle(frame, (x, y), 2, draw_color, 3)
                        info = f"{color.upper()}: D:{diameter_mm:.1f}mm X:{filtered_x_mm:.1f}mm Y:{filtered_y_mm:.1f}mm"
                        cv2.putText(frame, info, (x-70, y-10),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
                        # 串口发送色环数据
                        if ser is not None:
                            code = COLOR_CODE[color]
                            send_x = int(round(filtered_x_mm))
                            send_y = int(round(filtered_y_mm))
                            send_x = max(-127, min(127, send_x))
                            send_y = max(-127, min(127, send_y))
                            arr = [0xFE, code, int_to_hex_bytes(send_x), int_to_hex_bytes(send_y), 0xFF]
                            ser.write(bytes(arr))
                            print(f"发送{color}色环数据: {arr}")
                        # 只处理第一个检测到的非绿色色环
                        break
                    # 只要检测到任意非绿色色环，就不再继续检测其他颜色
                    break
        # 未检测到圆环时执行色块检测
        if not detected_circle:
            frame, block_order, block_data = detect_color_blocks_for_send(frame, BLOCK_COLOR_RANGES)
            send_flag = False
            if block_order is not None:
                # 检查是否与上一次顺序相同
                if block_order == last_block_order:
                    stable_count += 1
                    # 达到稳定阈值时标记为需要发送数据（停止转动）
                    if stable_count >= STABLE_FRAMES:
                        send_flag = True
                else:
                    # 顺序变化，重置稳定计数器（视为转动中）
                    stable_count = 0
                    last_block_order = block_order
            else:
                # 未检测到色块，重置状态（视为转动中）
                last_block_order = None
                stable_count = 0
            
            # 当稳定且需要发送时执行串口发送（停止转动时发送数据）
            if send_flag and ser is not None:
                # 保持原有6个数据不变，增加扇区4的x和y坐标（共8个数据）
                arr_data = [
                    0xFD,
                    block_data['red_code'], block_data['red_sector'], 
                    block_data['green_code'], block_data['green_sector'],
                    block_data['blue_code'], block_data['blue_sector'],
                    int_to_hex_bytes(block_data['sector4_x']),  # 新增：扇区4色块x坐标
                    int_to_hex_bytes(block_data['sector4_y']),  # 新增：扇区4色块y坐标
                    0xFC
                ]
                ser.write(bytes(arr_data))
                print(f"发送稳定色块数据: {arr_data}")
            
            center_queue.clear()  # 没有圆时清空滤波队列
        
        # 统一显示处理后的画面
        display_frame = cv2.resize(frame, (640, 360))
        cv2.imshow("Ring & Block Detection", display_frame)
        
        # 处理按键事件（按q键退出）
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break

    # 资源释放（保持在循环外）
    cap.release()
    cv2.destroyAllWindows()
    if ser is not None:
        ser.close()

if __name__ == "__main__":
    main()